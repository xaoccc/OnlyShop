var Rr = Object.defineProperty;
var xr = (n, t, e) => t in n ? Rr(n, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : n[t] = e;
var $e = (n, t, e) => (xr(n, typeof t != "symbol" ? t + "" : t, e), e);
/*!
* MDB5
* Version: FREE 7.1.0
*
*
* Copyright: Material Design for Bootstrap
* https://mdbootstrap.com/
*
* Read the license: https://mdbootstrap.com/general/license/
*
*
* Documentation: https://mdbootstrap.com/docs/standard/
*
* Support: https://mdbootstrap.com/support/
*
* Contact: contact@mdbootstrap.com
*
*/
const Ie = (() => {
  const n = {};
  let t = 1;
  return {
    set(e, i, s) {
      typeof e[i] > "u" && (e[i] = {
        key: i,
        id: t
      }, t++), n[e[i].id] = s;
    },
    get(e, i) {
      if (!e || typeof e[i] > "u")
        return null;
      const s = e[i];
      return s.key === i ? n[s.id] : null;
    },
    delete(e, i) {
      if (typeof e[i] > "u")
        return;
      const s = e[i];
      s.key === i && (delete n[s.id], delete e[i]);
    }
  };
})(), et = {
  setData(n, t, e) {
    Ie.set(n, t, e);
  },
  getData(n, t) {
    return Ie.get(n, t);
  },
  removeData(n, t) {
    Ie.delete(n, t);
  }
}, Pr = (n) => n == null ? `${n}` : {}.toString.call(n).match(/\s([a-z]+)/i)[1].toLowerCase(), is = (n) => {
  let t = n.getAttribute("data-mdb-target");
  if (!t || t === "#") {
    const e = n.getAttribute("href");
    t = e && e !== "#" ? e.trim() : null;
  }
  return t;
}, en = (n) => {
  const t = is(n);
  return t && document.querySelector(t) ? t : null;
}, Wt = (n) => {
  const t = is(n);
  return t ? document.querySelector(t) : null;
}, ss = (n) => !n || typeof n != "object" ? !1 : (typeof n.jquery < "u" && (n = n[0]), typeof n.nodeType < "u"), Bn = (n) => ss(n) ? n.jquery ? n[0] : n : typeof n == "string" && n.length > 0 ? document.querySelector(n) : null, rs = (n, t, e) => {
  Object.keys(e).forEach((i) => {
    const s = e[i], r = t[i], o = r && ss(r) ? "element" : Pr(r);
    if (!new RegExp(s).test(o))
      throw new Error(
        `${n.toUpperCase()}: Option "${i}" provided type "${o}" but expected type "${s}".`
      );
  });
}, os = (n) => {
  if (!n)
    return !1;
  if (n.style && n.parentNode && n.parentNode.style) {
    const t = getComputedStyle(n), e = getComputedStyle(n.parentNode);
    return t.display !== "none" && e.display !== "none" && t.visibility !== "hidden";
  }
  return !1;
}, as = (n) => !n || n.nodeType !== Node.ELEMENT_NODE || n.classList.contains("disabled") ? !0 : typeof n.disabled < "u" ? n.disabled : n.hasAttribute("disabled") && n.getAttribute("disabled") !== "false", ls = () => {
  const { jQuery: n } = window;
  return n && !document.body.hasAttribute("data-mdb-no-jquery") ? n : null;
}, cs = (n) => {
  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", n) : n();
};
document.documentElement.dir;
const At = (n) => document.createElement(n), kr = (n) => {
  cs(() => {
    const t = ls();
    if (t) {
      const e = n.NAME, i = t.fn[e];
      t.fn[e] = n.jQueryInterface, t.fn[e].Constructor = n, t.fn[e].noConflict = () => (t.fn[e] = i, n.jQueryInterface);
    }
  });
}, Me = ls(), Hr = /[^.]*(?=\..*)\.|.*/, us = /\..*/, Vr = /::\d+$/, Re = {};
let Wn = 1;
const Br = {
  mouseenter: "mouseover",
  mouseleave: "mouseout"
}, ds = [
  "click",
  "dblclick",
  "mouseup",
  "mousedown",
  "contextmenu",
  "mousewheel",
  "DOMMouseScroll",
  "mouseover",
  "mouseout",
  "mousemove",
  "selectstart",
  "selectend",
  "keydown",
  "keypress",
  "keyup",
  "orientationchange",
  "touchstart",
  "touchmove",
  "touchend",
  "touchcancel",
  "pointerdown",
  "pointermove",
  "pointerup",
  "pointerleave",
  "pointercancel",
  "gesturestart",
  "gesturechange",
  "gestureend",
  "focus",
  "blur",
  "change",
  "reset",
  "select",
  "submit",
  "focusin",
  "focusout",
  "load",
  "unload",
  "beforeunload",
  "resize",
  "move",
  "DOMContentLoaded",
  "readystatechange",
  "error",
  "abort",
  "scroll"
];
function hs(n, t) {
  return t && `${t}::${Wn++}` || n.uidEvent || Wn++;
}
function fs(n) {
  const t = hs(n);
  return n.uidEvent = t, Re[t] = Re[t] || {}, Re[t];
}
function Wr(n, t) {
  return function e(i) {
    return i.delegateTarget = n, e.oneOff && u.off(n, i.type, t), t.apply(n, [i]);
  };
}
function jr(n, t, e) {
  return function i(s) {
    const r = n.querySelectorAll(t);
    for (let { target: o } = s; o && o !== this; o = o.parentNode)
      for (let a = r.length; a--; "")
        if (r[a] === o)
          return s.delegateTarget = o, i.oneOff && u.off(n, s.type, e), e.apply(o, [s]);
    return null;
  };
}
function ps(n, t, e = null) {
  const i = Object.keys(n);
  for (let s = 0, r = i.length; s < r; s++) {
    const o = n[i[s]];
    if (o.originalHandler === t && o.delegationSelector === e)
      return o;
  }
  return null;
}
function _s(n, t, e) {
  const i = typeof t == "string", s = i ? e : t;
  let r = n.replace(us, "");
  const o = Br[r];
  return o && (r = o), ds.indexOf(r) > -1 || (r = n), [i, s, r];
}
function jn(n, t, e, i, s) {
  if (typeof t != "string" || !n)
    return;
  e || (e = i, i = null);
  const [r, o, a] = _s(
    t,
    e,
    i
  ), l = fs(n), d = l[a] || (l[a] = {}), c = ps(d, o, r ? e : null);
  if (c) {
    c.oneOff = c.oneOff && s;
    return;
  }
  const f = hs(o, t.replace(Hr, "")), g = r ? jr(n, e, i) : Wr(n, e);
  g.delegationSelector = r ? e : null, g.originalHandler = o, g.oneOff = s, g.uidEvent = f, d[f] = g, n.addEventListener(a, g, r);
}
function nn(n, t, e, i, s) {
  const r = ps(t[e], i, s);
  r && (n.removeEventListener(e, r, !!s), delete t[e][r.uidEvent]);
}
function Kr(n, t, e, i) {
  const s = t[e] || {};
  Object.keys(s).forEach((r) => {
    if (r.indexOf(i) > -1) {
      const o = s[r];
      nn(n, t, e, o.originalHandler, o.delegationSelector);
    }
  });
}
const u = {
  on(n, t, e, i) {
    jn(n, t, e, i, !1);
  },
  one(n, t, e, i) {
    jn(n, t, e, i, !0);
  },
  extend(n, t, e) {
    t.forEach((i) => {
      u.on(n, `${i.name}.bs.${e}`, (s) => {
        const r = {};
        i.parametersToCopy && i.parametersToCopy.forEach((a) => {
          r[a] = s[a];
        }), u.trigger(
          n,
          `${i.name}.mdb.${e}`,
          r
        ).defaultPrevented && s.preventDefault();
      });
    });
  },
  off(n, t, e, i) {
    if (typeof t != "string" || !n)
      return;
    const [s, r, o] = _s(
      t,
      e,
      i
    ), a = o !== t, l = fs(n), d = t.charAt(0) === ".";
    if (typeof r < "u") {
      if (!l || !l[o])
        return;
      nn(n, l, o, r, s ? e : null);
      return;
    }
    d && Object.keys(l).forEach((f) => {
      Kr(n, l, f, t.slice(1));
    });
    const c = l[o] || {};
    Object.keys(c).forEach((f) => {
      const g = f.replace(Vr, "");
      if (!a || t.indexOf(g) > -1) {
        const b = c[f];
        nn(n, l, o, b.originalHandler, b.delegationSelector);
      }
    });
  },
  trigger(n, t, e) {
    if (typeof t != "string" || !n)
      return null;
    const i = t.replace(us, ""), s = t !== i, r = ds.indexOf(i) > -1;
    let o, a = !0, l = !0, d = !1, c = null;
    return s && Me && (o = Me.Event(t, e), Me(n).trigger(o), a = !o.isPropagationStopped(), l = !o.isImmediatePropagationStopped(), d = o.isDefaultPrevented()), r ? (c = document.createEvent("HTMLEvents"), c.initEvent(i, a, !0)) : c = new CustomEvent(t, {
      bubbles: a,
      cancelable: !0
    }), typeof e < "u" && Object.keys(e).forEach((f) => {
      Object.defineProperty(c, f, {
        get() {
          return e[f];
        }
      });
    }), d && c.preventDefault(), l && n.dispatchEvent(c), c.defaultPrevented && typeof o < "u" && o.preventDefault(), c;
  }
};
function Kn(n) {
  return n === "true" ? !0 : n === "false" ? !1 : n === Number(n).toString() ? Number(n) : n === "" || n === "null" ? null : n;
}
function xe(n) {
  return n.replace(/[A-Z]/g, (t) => `-${t.toLowerCase()}`);
}
const _ = {
  setDataAttribute(n, t, e) {
    n.setAttribute(`data-mdb-${xe(t)}`, e);
  },
  removeDataAttribute(n, t) {
    n.removeAttribute(`data-mdb-${xe(t)}`);
  },
  getDataAttributes(n) {
    if (!n)
      return {};
    const t = {
      ...n.dataset
    };
    return Object.keys(t).filter((e) => e.startsWith("mdb")).forEach((e) => {
      let i = e.replace(/^mdb/, "");
      i = i.charAt(0).toLowerCase() + i.slice(1, i.length), t[i] = Kn(t[e]);
    }), t;
  },
  getDataAttribute(n, t) {
    return Kn(n.getAttribute(`data-mdb-${xe(t)}`));
  },
  offset(n) {
    const t = n.getBoundingClientRect();
    return {
      top: t.top + document.body.scrollTop,
      left: t.left + document.body.scrollLeft
    };
  },
  position(n) {
    return {
      top: n.offsetTop,
      left: n.offsetLeft
    };
  },
  style(n, t) {
    Object.assign(n.style, t);
  },
  toggleClass(n, t) {
    n && (n.classList.contains(t) ? n.classList.remove(t) : n.classList.add(t));
  },
  addClass(n, t) {
    n.classList.contains(t) || n.classList.add(t);
  },
  addStyle(n, t) {
    Object.keys(t).forEach((e) => {
      n.style[e] = t[e];
    });
  },
  removeClass(n, t) {
    n.classList.contains(t) && n.classList.remove(t);
  },
  hasClass(n, t) {
    return n.classList.contains(t);
  }
}, Fr = 3, v = {
  closest(n, t) {
    return n.closest(t);
  },
  matches(n, t) {
    return n.matches(t);
  },
  find(n, t = document.documentElement) {
    return [].concat(...Element.prototype.querySelectorAll.call(t, n));
  },
  findOne(n, t = document.documentElement) {
    return Element.prototype.querySelector.call(t, n);
  },
  children(n, t) {
    return [].concat(...n.children).filter((i) => i.matches(t));
  },
  parents(n, t) {
    const e = [];
    let i = n.parentNode;
    for (; i && i.nodeType === Node.ELEMENT_NODE && i.nodeType !== Fr; )
      this.matches(i, t) && e.push(i), i = i.parentNode;
    return e;
  },
  prev(n, t) {
    let e = n.previousElementSibling;
    for (; e; ) {
      if (e.matches(t))
        return [e];
      e = e.previousElementSibling;
    }
    return [];
  },
  next(n, t) {
    let e = n.nextElementSibling;
    for (; e; ) {
      if (this.matches(e, t))
        return [e];
      e = e.nextElementSibling;
    }
    return [];
  }
}, tt = /* @__PURE__ */ new Map(), Pe = {
  set(n, t, e) {
    tt.has(n) || tt.set(n, /* @__PURE__ */ new Map());
    const i = tt.get(n);
    if (!i.has(t) && i.size !== 0) {
      console.error(
        `Bootstrap doesn't allow more than one instance per element. Bound instance: ${Array.from(i.keys())[0]}.`
      );
      return;
    }
    i.set(t, e);
  },
  get(n, t) {
    return tt.has(n) && tt.get(n).get(t) || null;
  },
  remove(n, t) {
    if (!tt.has(n))
      return;
    const e = tt.get(n);
    e.delete(t), e.size === 0 && tt.delete(n);
  }
}, Ur = 1e6, Yr = 1e3, sn = "transitionend", ms = (n) => (n && window.CSS && window.CSS.escape && (n = n.replace(/#([^\s"#']+)/g, (t, e) => `#${CSS.escape(e)}`)), n), zr = (n) => n == null ? `${n}` : Object.prototype.toString.call(n).match(/\s([a-z]+)/i)[1].toLowerCase(), Gr = (n) => {
  do
    n += Math.floor(Math.random() * Ur);
  while (document.getElementById(n));
  return n;
}, qr = (n) => {
  if (!n)
    return 0;
  let { transitionDuration: t, transitionDelay: e } = window.getComputedStyle(n);
  const i = Number.parseFloat(t), s = Number.parseFloat(e);
  return !i && !s ? 0 : (t = t.split(",")[0], e = e.split(",")[0], (Number.parseFloat(t) + Number.parseFloat(e)) * Yr);
}, Es = (n) => {
  n.dispatchEvent(new Event(sn));
}, Q = (n) => !n || typeof n != "object" ? !1 : (typeof n.jquery < "u" && (n = n[0]), typeof n.nodeType < "u"), it = (n) => Q(n) ? n.jquery ? n[0] : n : typeof n == "string" && n.length > 0 ? document.querySelector(ms(n)) : null, Ee = (n) => {
  if (!Q(n) || n.getClientRects().length === 0)
    return !1;
  const t = getComputedStyle(n).getPropertyValue("visibility") === "visible", e = n.closest("details:not([open])");
  if (!e)
    return t;
  if (e !== n) {
    const i = n.closest("summary");
    if (i && i.parentNode !== e || i === null)
      return !1;
  }
  return t;
}, Nt = (n) => !n || n.nodeType !== Node.ELEMENT_NODE || n.classList.contains("disabled") ? !0 : typeof n.disabled < "u" ? n.disabled : n.hasAttribute("disabled") && n.getAttribute("disabled") !== "false", gs = (n) => {
  if (!document.documentElement.attachShadow)
    return null;
  if (typeof n.getRootNode == "function") {
    const t = n.getRootNode();
    return t instanceof ShadowRoot ? t : null;
  }
  return n instanceof ShadowRoot ? n : n.parentNode ? gs(n.parentNode) : null;
}, he = () => {
}, jt = (n) => {
  n.offsetHeight;
}, Xr = () => window.jQuery && !document.body.hasAttribute("data-mdb-no-jquery") ? window.jQuery : null, F = () => document.documentElement.dir === "rtl", k = (n, t = [], e = n) => typeof n == "function" ? n(...t) : e, bs = (n, t, e = !0) => {
  if (!e) {
    k(n);
    return;
  }
  const i = 5, s = qr(t) + i;
  let r = !1;
  const o = ({ target: a }) => {
    a === t && (r = !0, t.removeEventListener(sn, o), k(n));
  };
  t.addEventListener(sn, o), setTimeout(() => {
    r || Es(t);
  }, s);
}, _n = (n, t, e, i) => {
  const s = n.length;
  let r = n.indexOf(t);
  return r === -1 ? !e && i ? n[s - 1] : n[0] : (r += e ? 1 : -1, i && (r = (r + s) % s), n[Math.max(0, Math.min(r, s - 1))]);
}, Qr = /[^.]*(?=\..*)\.|.*/, Zr = /\..*/, Jr = /::\d+$/, ke = {};
let Fn = 1;
const vs = {
  mouseenter: "mouseover",
  mouseleave: "mouseout"
}, to = /* @__PURE__ */ new Set([
  "click",
  "dblclick",
  "mouseup",
  "mousedown",
  "contextmenu",
  "mousewheel",
  "DOMMouseScroll",
  "mouseover",
  "mouseout",
  "mousemove",
  "selectstart",
  "selectend",
  "keydown",
  "keypress",
  "keyup",
  "orientationchange",
  "touchstart",
  "touchmove",
  "touchend",
  "touchcancel",
  "pointerdown",
  "pointermove",
  "pointerup",
  "pointerleave",
  "pointercancel",
  "gesturestart",
  "gesturechange",
  "gestureend",
  "focus",
  "blur",
  "change",
  "reset",
  "select",
  "submit",
  "focusin",
  "focusout",
  "load",
  "unload",
  "beforeunload",
  "resize",
  "move",
  "DOMContentLoaded",
  "readystatechange",
  "error",
  "abort",
  "scroll"
]);
function Ts(n, t) {
  return t && `${t}::${Fn++}` || n.uidEvent || Fn++;
}
function As(n) {
  const t = Ts(n);
  return n.uidEvent = t, ke[t] = ke[t] || {}, ke[t];
}
function eo(n, t) {
  return function e(i) {
    return mn(i, { delegateTarget: n }), e.oneOff && h.off(n, i.type, t), t.apply(n, [i]);
  };
}
function no(n, t, e) {
  return function i(s) {
    const r = n.querySelectorAll(t);
    for (let { target: o } = s; o && o !== this; o = o.parentNode)
      for (const a of r)
        if (a === o)
          return mn(s, { delegateTarget: o }), i.oneOff && h.off(n, s.type, t, e), e.apply(o, [s]);
  };
}
function ys(n, t, e = null) {
  return Object.values(n).find(
    (i) => i.callable === t && i.delegationSelector === e
  );
}
function Ns(n, t, e) {
  const i = typeof t == "string", s = i ? e : t || e;
  let r = Cs(n);
  return to.has(r) || (r = n), [i, s, r];
}
function Un(n, t, e, i, s) {
  if (typeof t != "string" || !n)
    return;
  let [r, o, a] = Ns(
    t,
    e,
    i
  );
  t in vs && (o = ((O) => function(N) {
    if (!N.relatedTarget || N.relatedTarget !== N.delegateTarget && !N.delegateTarget.contains(N.relatedTarget))
      return O.call(this, N);
  })(o));
  const l = As(n), d = l[a] || (l[a] = {}), c = ys(d, o, r ? e : null);
  if (c) {
    c.oneOff = c.oneOff && s;
    return;
  }
  const f = Ts(o, t.replace(Qr, "")), g = r ? no(n, e, o) : eo(n, o);
  g.delegationSelector = r ? e : null, g.callable = o, g.oneOff = s, g.uidEvent = f, d[f] = g, n.addEventListener(a, g, r);
}
function rn(n, t, e, i, s) {
  const r = ys(t[e], i, s);
  r && (n.removeEventListener(e, r, !!s), delete t[e][r.uidEvent]);
}
function io(n, t, e, i) {
  const s = t[e] || {};
  for (const [r, o] of Object.entries(s))
    r.includes(i) && rn(n, t, e, o.callable, o.delegationSelector);
}
function Cs(n) {
  return n = n.replace(Zr, ""), vs[n] || n;
}
const h = {
  on(n, t, e, i) {
    Un(n, t, e, i, !1);
  },
  one(n, t, e, i) {
    Un(n, t, e, i, !0);
  },
  off(n, t, e, i) {
    if (typeof t != "string" || !n)
      return;
    const [s, r, o] = Ns(
      t,
      e,
      i
    ), a = o !== t, l = As(n), d = l[o] || {}, c = t.startsWith(".");
    if (typeof r < "u") {
      if (!Object.keys(d).length)
        return;
      rn(n, l, o, r, s ? e : null);
      return;
    }
    if (c)
      for (const f of Object.keys(l))
        io(n, l, f, t.slice(1));
    for (const [f, g] of Object.entries(d)) {
      const b = f.replace(Jr, "");
      (!a || t.includes(b)) && rn(n, l, o, g.callable, g.delegationSelector);
    }
  },
  trigger(n, t, e) {
    if (typeof t != "string" || !n)
      return null;
    const i = Xr(), s = Cs(t), r = t !== s;
    let o = null, a = !0, l = !0, d = !1;
    r && i && (o = i.Event(t, e), i(n).trigger(o), a = !o.isPropagationStopped(), l = !o.isImmediatePropagationStopped(), d = o.isDefaultPrevented());
    const c = mn(new Event(t, { bubbles: a, cancelable: !0 }), e);
    return d && c.preventDefault(), l && n.dispatchEvent(c), c.defaultPrevented && o && o.preventDefault(), c;
  }
};
function mn(n, t = {}) {
  for (const [e, i] of Object.entries(t))
    try {
      n[e] = i;
    } catch {
      Object.defineProperty(n, e, {
        configurable: !0,
        get() {
          return i;
        }
      });
    }
  return n;
}
function Yn(n) {
  if (n === "true")
    return !0;
  if (n === "false")
    return !1;
  if (n === Number(n).toString())
    return Number(n);
  if (n === "" || n === "null")
    return null;
  if (typeof n != "string")
    return n;
  try {
    return JSON.parse(decodeURIComponent(n));
  } catch {
    return n;
  }
}
function He(n) {
  return n.replace(/[A-Z]/g, (t) => `-${t.toLowerCase()}`);
}
const nt = {
  setDataAttribute(n, t, e) {
    n.setAttribute(`data-mdb-${He(t)}`, e);
  },
  removeDataAttribute(n, t) {
    n.removeAttribute(`data-mdb-${He(t)}`);
  },
  getDataAttributes(n) {
    if (!n)
      return {};
    const t = {}, e = Object.keys(n.dataset).filter(
      (i) => i.startsWith("mdb") && !i.startsWith("mdbConfig")
    );
    for (const i of e) {
      let s = i.replace(/^mdb/, "");
      s = s.charAt(0).toLowerCase() + s.slice(1, s.length), t[s] = Yn(n.dataset[i]);
    }
    return t;
  },
  getDataAttribute(n, t) {
    return Yn(n.getAttribute(`data-mdb-${He(t)}`));
  }
};
class Kt {
  // Getters
  static get Default() {
    return {};
  }
  static get DefaultType() {
    return {};
  }
  static get NAME() {
    throw new Error('You have to implement the static method "NAME", for each component!');
  }
  _getConfig(t) {
    return t = this._mergeConfigObj(t), t = this._configAfterMerge(t), this._typeCheckConfig(t), t;
  }
  _configAfterMerge(t) {
    return t;
  }
  _mergeConfigObj(t, e) {
    const i = Q(e) ? nt.getDataAttribute(e, "config") : {};
    return {
      ...this.constructor.Default,
      ...typeof i == "object" ? i : {},
      ...Q(e) ? nt.getDataAttributes(e) : {},
      ...typeof t == "object" ? t : {}
    };
  }
  _typeCheckConfig(t, e = this.constructor.DefaultType) {
    for (const [i, s] of Object.entries(e)) {
      const r = t[i], o = Q(r) ? "element" : zr(r);
      if (!new RegExp(s).test(o))
        throw new TypeError(
          `${this.constructor.NAME.toUpperCase()}: Option "${i}" provided type "${o}" but expected type "${s}".`
        );
    }
  }
}
const so = "5.3.2";
let z = class extends Kt {
  constructor(t, e) {
    super(), t = it(t), t && (this._element = t, this._config = this._getConfig(e), Pe.set(this._element, this.constructor.DATA_KEY, this));
  }
  // Public
  dispose() {
    Pe.remove(this._element, this.constructor.DATA_KEY), h.off(this._element, this.constructor.EVENT_KEY);
    for (const t of Object.getOwnPropertyNames(this))
      this[t] = null;
  }
  _queueCallback(t, e, i = !0) {
    bs(t, e, i);
  }
  _getConfig(t) {
    return t = this._mergeConfigObj(t, this._element), t = this._configAfterMerge(t), this._typeCheckConfig(t), t;
  }
  // Static
  static getInstance(t) {
    return Pe.get(it(t), this.DATA_KEY);
  }
  static getOrCreateInstance(t, e = {}) {
    return this.getInstance(t) || new this(t, typeof e == "object" ? e : null);
  }
  static get VERSION() {
    return so;
  }
  static get DATA_KEY() {
    return `bs.${this.NAME}`;
  }
  static get EVENT_KEY() {
    return `.${this.DATA_KEY}`;
  }
  static eventName(t) {
    return `${t}${this.EVENT_KEY}`;
  }
};
const ro = "button", oo = "active";
let ao = class ws extends z {
  // Getters
  static get NAME() {
    return ro;
  }
  // Public
  toggle() {
    this._element.setAttribute("aria-pressed", this._element.classList.toggle(oo));
  }
  // Static
  static jQueryInterface(t) {
    return this.each(function() {
      const e = ws.getOrCreateInstance(this);
      t === "toggle" && e[t]();
    });
  }
};
const zn = (() => {
  const n = [];
  return {
    set(t) {
      n.push(t);
    },
    get(t) {
      return n.includes(t);
    }
  };
})(), fe = {
  set(n) {
    zn.set(n);
  },
  get(n) {
    return zn.get(n);
  }
}, lo = (n) => fe.get(n), H = (n) => {
  lo(n.NAME) || Ss(n, !0);
}, Ss = (n, t = !1) => {
  if (!n || fe.get(n.NAME))
    return;
  fe.set(n.NAME);
  const e = gt[n.NAME] || null, i = (e == null ? void 0 : e.isToggler) || !1;
  if (kr(n), e != null && e.advanced) {
    e.advanced(n, e == null ? void 0 : e.selector);
    return;
  }
  if (i) {
    e.callback(n, e == null ? void 0 : e.selector);
    return;
  }
  t || v.find(e == null ? void 0 : e.selector).forEach((s) => {
    let r = n.getInstance(s);
    r || (r = new n(s), e != null && e.onInit && r[e.onInit]());
  });
};
let gt;
class co {
  constructor(t) {
    $e(this, "init", (t) => {
      t.forEach((e) => Ss(e));
    });
    $e(this, "initMDB", (t, e = !1) => {
      const i = Object.keys(gt).map((s) => {
        if (!!document.querySelector(gt[s].selector)) {
          const o = t[gt[s].name];
          return !o && !fe.get(s) && e && console.warn(
            `Please import ${gt[s].name} from "MDB" package and add it to a object parameter inside "initMDB" function`
          ), o;
        }
        return null;
      });
      this.init(i);
    });
    gt = t;
  }
}
const Os = "button", on = `mdb.${Os}`, Ft = `.${on}`, Gn = `click${Ft}`, _t = "transitionend", qn = "mouseenter", Xn = "mouseleave", uo = `hide${Ft}`, ho = `hidden${Ft}`, fo = `show${Ft}`, po = `shown${Ft}`, Qn = "active", _o = "shown", Zt = "fixed-action-btn", mo = ".fixed-action-btn:not(.smooth-scroll) > .btn-floating", Eo = "ul .btn", go = "ul";
class Ds extends ao {
  constructor(t) {
    super(t), this._fn = {}, this._element && (et.setData(this._element, on, this), this._init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor));
  }
  // Static
  static get NAME() {
    return Os;
  }
  static jQueryInterface(t, e) {
    return this.each(function() {
      let i = et.getData(this, on);
      const s = typeof t == "object" && t;
      if (!(!i && /dispose/.test(t)) && (i || (i = new Ds(this, s)), typeof t == "string")) {
        if (typeof i[t] > "u")
          throw new TypeError(`No method named "${t}"`);
        i[t](e);
      }
    });
  }
  // Getters
  get _actionButton() {
    return v.findOne(mo, this._element);
  }
  get _buttonListElements() {
    return v.find(Eo, this._element);
  }
  get _buttonList() {
    return v.findOne(go, this._element);
  }
  get _isTouchDevice() {
    return "ontouchstart" in document.documentElement;
  }
  // Public
  show() {
    _.hasClass(this._element, Zt) && (u.off(this._buttonList, _t), u.trigger(this._element, fo), this._bindListOpenTransitionEnd(), _.addStyle(this._element, { height: `${this._fullContainerHeight}px` }), this._toggleVisibility(!0));
  }
  hide() {
    _.hasClass(this._element, Zt) && (u.off(this._buttonList, _t), u.trigger(this._element, uo), this._bindListHideTransitionEnd(), this._toggleVisibility(!1));
  }
  dispose() {
    _.hasClass(this._element, Zt) && (u.off(this._actionButton, Gn), this._actionButton.removeEventListener(qn, this._fn.mouseenter), this._element.removeEventListener(Xn, this._fn.mouseleave)), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Private
  _init() {
    _.hasClass(this._element, Zt) && (this._saveInitialHeights(), this._setInitialStyles(), this._bindInitialEvents());
  }
  _bindMouseEnter() {
    this._actionButton.addEventListener(
      qn,
      // prettier-ignore
      this._fn.mouseenter = () => {
        this._isTouchDevice || this.show();
      }
      // prettier-ignore
    );
  }
  _bindMouseLeave() {
    this._element.addEventListener(
      Xn,
      // prettier-ignore
      this._fn.mouseleave = () => {
        this.hide();
      }
      // prettier-ignore
    );
  }
  _bindClick() {
    u.on(this._actionButton, Gn, () => {
      _.hasClass(this._element, Qn) ? this.hide() : this.show();
    });
  }
  _bindListHideTransitionEnd() {
    u.on(this._buttonList, _t, (t) => {
      t.propertyName === "transform" && (u.off(this._buttonList, _t), this._element.style.height = `${this._initialContainerHeight}px`, u.trigger(this._element, ho));
    });
  }
  _bindListOpenTransitionEnd() {
    u.on(this._buttonList, _t, (t) => {
      t.propertyName === "transform" && (u.off(this._buttonList, _t), u.trigger(this._element, po));
    });
  }
  _toggleVisibility(t) {
    const e = t ? "addClass" : "removeClass", i = t ? "translate(0)" : `translateY(${this._fullContainerHeight}px)`;
    _.addStyle(this._buttonList, { transform: i }), this._buttonListElements && this._buttonListElements.forEach((s) => _[e](s, _o)), _[e](this._element, Qn);
  }
  _getHeight(t) {
    const e = window.getComputedStyle(t);
    return parseFloat(e.getPropertyValue("height"));
  }
  _saveInitialHeights() {
    this._initialContainerHeight = this._getHeight(this._element), this._initialListHeight = this._getHeight(this._buttonList), this._fullContainerHeight = this._initialContainerHeight + this._initialListHeight;
  }
  _bindInitialEvents() {
    this._bindClick(), this._bindMouseEnter(), this._bindMouseLeave();
  }
  _setInitialStyles() {
    this._buttonList.style.marginBottom = `${this._initialContainerHeight}px`, this._buttonList.style.transform = `translateY(${this._fullContainerHeight}px)`, this._element.style.height = `${this._initialContainerHeight}px`;
  }
}
const Ve = (n) => {
  let t = n.getAttribute("data-mdb-target");
  if (!t || t === "#") {
    let e = n.getAttribute("href");
    if (!e || !e.includes("#") && !e.startsWith("."))
      return null;
    e.includes("#") && !e.startsWith("#") && (e = `#${e.split("#")[1]}`), t = e && e !== "#" ? ms(e.trim()) : null;
  }
  return t;
}, y = {
  find(n, t = document.documentElement) {
    return [].concat(...Element.prototype.querySelectorAll.call(t, n));
  },
  findOne(n, t = document.documentElement) {
    return Element.prototype.querySelector.call(t, n);
  },
  children(n, t) {
    return [].concat(...n.children).filter((e) => e.matches(t));
  },
  parents(n, t) {
    const e = [];
    let i = n.parentNode.closest(t);
    for (; i; )
      e.push(i), i = i.parentNode.closest(t);
    return e;
  },
  prev(n, t) {
    let e = n.previousElementSibling;
    for (; e; ) {
      if (e.matches(t))
        return [e];
      e = e.previousElementSibling;
    }
    return [];
  },
  // TODO: this is now unused; remove later along with prev()
  next(n, t) {
    let e = n.nextElementSibling;
    for (; e; ) {
      if (e.matches(t))
        return [e];
      e = e.nextElementSibling;
    }
    return [];
  },
  focusableChildren(n) {
    const t = [
      "a",
      "button",
      "input",
      "textarea",
      "select",
      "details",
      "[tabindex]",
      '[contenteditable="true"]'
    ].map((e) => `${e}:not([tabindex^="-"])`).join(",");
    return this.find(t, n).filter((e) => !Nt(e) && Ee(e));
  },
  getSelectorFromElement(n) {
    const t = Ve(n);
    return t && y.findOne(t) ? t : null;
  },
  getElementFromSelector(n) {
    const t = Ve(n);
    return t ? y.findOne(t) : null;
  },
  getMultipleElementsFromSelector(n) {
    const t = Ve(n);
    return t ? y.find(t) : [];
  }
}, Ls = "backdrop", bo = "fade", Zn = "show", Jn = `mousedown.bs.${Ls}`, vo = {
  className: "modal-backdrop",
  clickCallback: null,
  isAnimated: !1,
  isVisible: !0,
  // if false, we use the backdrop helper without adding any element to the dom
  rootElement: "body"
  // give the choice to place backdrop under different elements
}, To = {
  className: "string",
  clickCallback: "(function|null)",
  isAnimated: "boolean",
  isVisible: "boolean",
  rootElement: "(element|string)"
};
class $s extends Kt {
  constructor(t) {
    super(), this._config = this._getConfig(t), this._isAppended = !1, this._element = null;
  }
  // Getters
  static get Default() {
    return vo;
  }
  static get DefaultType() {
    return To;
  }
  static get NAME() {
    return Ls;
  }
  // Public
  show(t) {
    if (!this._config.isVisible) {
      k(t);
      return;
    }
    this._append();
    const e = this._getElement();
    this._config.isAnimated && jt(e), e.classList.add(Zn), this._emulateAnimation(() => {
      k(t);
    });
  }
  hide(t) {
    if (!this._config.isVisible) {
      k(t);
      return;
    }
    this._getElement().classList.remove(Zn), this._emulateAnimation(() => {
      this.dispose(), k(t);
    });
  }
  dispose() {
    this._isAppended && (h.off(this._element, Jn), this._element.remove(), this._isAppended = !1);
  }
  // Private
  _getElement() {
    if (!this._element) {
      const t = document.createElement("div");
      t.className = this._config.className, this._config.isAnimated && t.classList.add(bo), this._element = t;
    }
    return this._element;
  }
  _configAfterMerge(t) {
    return t.rootElement = it(t.rootElement), t;
  }
  _append() {
    if (this._isAppended)
      return;
    const t = this._getElement();
    this._config.rootElement.append(t), h.on(t, Jn, () => {
      k(this._config.clickCallback);
    }), this._isAppended = !0;
  }
  _emulateAnimation(t) {
    bs(t, this._getElement(), this._config.isAnimated);
  }
}
const ge = (n, t = "hide") => {
  const e = `click.dismiss${n.EVENT_KEY}`, i = n.NAME;
  h.on(document, e, `[data-mdb-dismiss="${i}"]`, function(s) {
    if (["A", "AREA"].includes(this.tagName) && s.preventDefault(), Nt(this))
      return;
    const r = y.getElementFromSelector(this) || this.closest(`.${i}`);
    n.getOrCreateInstance(r)[t]();
  });
}, Ao = "focustrap", yo = "bs.focustrap", pe = `.${yo}`, No = `focusin${pe}`, Co = `keydown.tab${pe}`, wo = "Tab", So = "forward", ti = "backward", Oo = {
  autofocus: !0,
  trapElement: null
  // The element to trap focus inside of
}, Do = {
  autofocus: "boolean",
  trapElement: "element"
};
class Is extends Kt {
  constructor(t) {
    super(), this._config = this._getConfig(t), this._isActive = !1, this._lastTabNavDirection = null;
  }
  // Getters
  static get Default() {
    return Oo;
  }
  static get DefaultType() {
    return Do;
  }
  static get NAME() {
    return Ao;
  }
  // Public
  activate() {
    this._isActive || (this._config.autofocus && this._config.trapElement.focus(), h.off(document, pe), h.on(document, No, (t) => this._handleFocusin(t)), h.on(document, Co, (t) => this._handleKeydown(t)), this._isActive = !0);
  }
  deactivate() {
    this._isActive && (this._isActive = !1, h.off(document, pe));
  }
  // Private
  _handleFocusin(t) {
    const { trapElement: e } = this._config;
    if (t.target === document || t.target === e || e.contains(t.target))
      return;
    const i = y.focusableChildren(e);
    i.length === 0 ? e.focus() : this._lastTabNavDirection === ti ? i[i.length - 1].focus() : i[0].focus();
  }
  _handleKeydown(t) {
    t.key === wo && (this._lastTabNavDirection = t.shiftKey ? ti : So);
  }
}
const ei = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top", ni = ".sticky-top", Jt = "padding-right", ii = "margin-right";
class an {
  constructor() {
    this._element = document.body;
  }
  // Public
  getWidth() {
    const t = document.documentElement.clientWidth;
    return Math.abs(window.innerWidth - t);
  }
  hide() {
    const t = this.getWidth();
    this._disableOverFlow(), this._setElementAttributes(
      this._element,
      Jt,
      (e) => e + t
    ), this._setElementAttributes(
      ei,
      Jt,
      (e) => e + t
    ), this._setElementAttributes(
      ni,
      ii,
      (e) => e - t
    );
  }
  reset() {
    this._resetElementAttributes(this._element, "overflow"), this._resetElementAttributes(this._element, Jt), this._resetElementAttributes(ei, Jt), this._resetElementAttributes(ni, ii);
  }
  isOverflowing() {
    return this.getWidth() > 0;
  }
  // Private
  _disableOverFlow() {
    this._saveInitialAttribute(this._element, "overflow"), this._element.style.overflow = "hidden";
  }
  _setElementAttributes(t, e, i) {
    const s = this.getWidth(), r = (o) => {
      if (o !== this._element && window.innerWidth > o.clientWidth + s)
        return;
      this._saveInitialAttribute(o, e);
      const a = window.getComputedStyle(o).getPropertyValue(e);
      o.style.setProperty(e, `${i(Number.parseFloat(a))}px`);
    };
    this._applyManipulationCallback(t, r);
  }
  _saveInitialAttribute(t, e) {
    const i = t.style.getPropertyValue(e);
    i && nt.setDataAttribute(t, e, i);
  }
  _resetElementAttributes(t, e) {
    const i = (s) => {
      const r = nt.getDataAttribute(s, e);
      if (r === null) {
        s.style.removeProperty(e);
        return;
      }
      nt.removeDataAttribute(s, e), s.style.setProperty(e, r);
    };
    this._applyManipulationCallback(t, i);
  }
  _applyManipulationCallback(t, e) {
    if (Q(t)) {
      e(t);
      return;
    }
    for (const i of y.find(t, this._element))
      e(i);
  }
}
const Lo = "offcanvas", $o = "bs.offcanvas", Lt = `.${$o}`, Io = "Escape", si = "show", ri = "showing", oi = "hiding", Mo = "offcanvas-backdrop", Ro = `show${Lt}`, xo = `shown${Lt}`, Po = `hide${Lt}`, ai = `hidePrevented${Lt}`, ko = `hidden${Lt}`, Ho = `keydown.dismiss${Lt}`, Vo = {
  backdrop: !0,
  keyboard: !0,
  scroll: !1
}, Bo = {
  backdrop: "(boolean|string)",
  keyboard: "boolean",
  scroll: "boolean"
};
class Ms extends z {
  constructor(t, e) {
    super(t, e), this._isShown = !1, this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._addEventListeners();
  }
  // Getters
  static get Default() {
    return Vo;
  }
  static get DefaultType() {
    return Bo;
  }
  static get NAME() {
    return Lo;
  }
  // Public
  toggle(t) {
    return this._isShown ? this.hide() : this.show(t);
  }
  show(t) {
    if (this._isShown || h.trigger(this._element, Ro, { relatedTarget: t }).defaultPrevented)
      return;
    this._isShown = !0, this._backdrop.show(), this._config.scroll || new an().hide(), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.classList.add(ri);
    const i = () => {
      (!this._config.scroll || this._config.backdrop) && this._focustrap.activate(), this._element.classList.add(si), this._element.classList.remove(ri), h.trigger(this._element, xo, { relatedTarget: t });
    };
    this._queueCallback(i, this._element, !0);
  }
  hide() {
    if (!this._isShown || h.trigger(this._element, Po).defaultPrevented)
      return;
    this._focustrap.deactivate(), this._element.blur(), this._isShown = !1, this._element.classList.add(oi), this._backdrop.hide();
    const e = () => {
      this._element.classList.remove(si, oi), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._config.scroll || new an().reset(), h.trigger(this._element, ko);
    };
    this._queueCallback(e, this._element, !0);
  }
  dispose() {
    this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
  }
  // Private
  _initializeBackDrop() {
    const t = () => {
      if (this._config.backdrop === "static") {
        h.trigger(this._element, ai);
        return;
      }
      this.hide();
    }, e = !!this._config.backdrop;
    return new $s({
      className: Mo,
      isVisible: e,
      isAnimated: !0,
      rootElement: this._element.parentNode,
      clickCallback: e ? t : null
    });
  }
  _initializeFocusTrap() {
    return new Is({
      trapElement: this._element
    });
  }
  _addEventListeners() {
    h.on(this._element, Ho, (t) => {
      if (t.key === Io) {
        if (this._config.keyboard) {
          this.hide();
          return;
        }
        h.trigger(this._element, ai);
      }
    });
  }
  // Static
  static jQueryInterface(t) {
    return this.each(function() {
      const e = Ms.getOrCreateInstance(this, t);
      if (typeof t == "string") {
        if (e[t] === void 0 || t.startsWith("_") || t === "constructor")
          throw new TypeError(`No method named "${t}"`);
        e[t](this);
      }
    });
  }
}
const Wo = "alert", jo = "bs.alert", Rs = `.${jo}`, Ko = `close${Rs}`, Fo = `closed${Rs}`, Uo = "fade", Yo = "show";
let zo = class xs extends z {
  // Getters
  static get NAME() {
    return Wo;
  }
  // Public
  close() {
    if (h.trigger(this._element, Ko).defaultPrevented)
      return;
    this._element.classList.remove(Yo);
    const e = this._element.classList.contains(Uo);
    this._queueCallback(() => this._destroyElement(), this._element, e);
  }
  // Private
  _destroyElement() {
    this._element.remove(), h.trigger(this._element, Fo), this.dispose();
  }
  // Static
  static jQueryInterface(t) {
    return this.each(function() {
      const e = xs.getOrCreateInstance(this);
      if (typeof t == "string") {
        if (e[t] === void 0 || t.startsWith("_") || t === "constructor")
          throw new TypeError(`No method named "${t}"`);
        e[t](this);
      }
    });
  }
};
const li = "alert", Go = "close.bs.alert", qo = "closed.bs.alert", Xo = [{ name: "close" }, { name: "closed" }];
class wh extends zo {
  constructor(t, e = {}) {
    super(t, e), this._init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor);
  }
  dispose() {
    u.off(this._element, Go), u.off(this._element, qo), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Getters
  static get NAME() {
    return li;
  }
  // Private
  _init() {
    this._bindMdbEvents();
  }
  _bindMdbEvents() {
    u.extend(this._element, Xo, li);
  }
}
const Qo = "swipe", $t = ".bs.swipe", Zo = `touchstart${$t}`, Jo = `touchmove${$t}`, ta = `touchend${$t}`, ea = `pointerdown${$t}`, na = `pointerup${$t}`, ia = "touch", sa = "pen", ra = "pointer-event", oa = 40, aa = {
  endCallback: null,
  leftCallback: null,
  rightCallback: null
}, la = {
  endCallback: "(function|null)",
  leftCallback: "(function|null)",
  rightCallback: "(function|null)"
};
class _e extends Kt {
  constructor(t, e) {
    super(), this._element = t, !(!t || !_e.isSupported()) && (this._config = this._getConfig(e), this._deltaX = 0, this._supportPointerEvents = !!window.PointerEvent, this._initEvents());
  }
  // Getters
  static get Default() {
    return aa;
  }
  static get DefaultType() {
    return la;
  }
  static get NAME() {
    return Qo;
  }
  // Public
  dispose() {
    h.off(this._element, $t);
  }
  // Private
  _start(t) {
    if (!this._supportPointerEvents) {
      this._deltaX = t.touches[0].clientX;
      return;
    }
    this._eventIsPointerPenTouch(t) && (this._deltaX = t.clientX);
  }
  _end(t) {
    this._eventIsPointerPenTouch(t) && (this._deltaX = t.clientX - this._deltaX), this._handleSwipe(), k(this._config.endCallback);
  }
  _move(t) {
    this._deltaX = t.touches && t.touches.length > 1 ? 0 : t.touches[0].clientX - this._deltaX;
  }
  _handleSwipe() {
    const t = Math.abs(this._deltaX);
    if (t <= oa)
      return;
    const e = t / this._deltaX;
    this._deltaX = 0, e && k(e > 0 ? this._config.rightCallback : this._config.leftCallback);
  }
  _initEvents() {
    this._supportPointerEvents ? (h.on(this._element, ea, (t) => this._start(t)), h.on(this._element, na, (t) => this._end(t)), this._element.classList.add(ra)) : (h.on(this._element, Zo, (t) => this._start(t)), h.on(this._element, Jo, (t) => this._move(t)), h.on(this._element, ta, (t) => this._end(t)));
  }
  _eventIsPointerPenTouch(t) {
    return this._supportPointerEvents && (t.pointerType === sa || t.pointerType === ia);
  }
  // Static
  static isSupported() {
    return "ontouchstart" in document.documentElement || navigator.maxTouchPoints > 0;
  }
}
const ca = "carousel", ua = "bs.carousel", It = `.${ua}`, da = "ArrowLeft", ha = "ArrowRight", fa = 500, Pt = "next", mt = "prev", bt = "left", ce = "right", pa = `slide${It}`, Be = `slid${It}`, _a = `keydown${It}`, ma = `mouseenter${It}`, Ea = `mouseleave${It}`, ga = `dragstart${It}`, ba = "carousel", te = "active", va = "slide", Ta = "carousel-item-end", Aa = "carousel-item-start", ya = "carousel-item-next", Na = "carousel-item-prev", Ps = ".active", ks = ".carousel-item", Ca = Ps + ks, wa = ".carousel-item img", Sa = ".carousel-indicators", Oa = {
  [da]: ce,
  [ha]: bt
}, Da = {
  interval: 5e3,
  keyboard: !0,
  pause: "hover",
  ride: !1,
  touch: !0,
  wrap: !0
}, La = {
  interval: "(number|boolean)",
  // TODO:v6 remove boolean support
  keyboard: "boolean",
  pause: "(string|boolean)",
  ride: "(boolean|string)",
  touch: "boolean",
  wrap: "boolean"
};
let $a = class Hs extends z {
  constructor(t, e) {
    super(t, e), this._interval = null, this._activeElement = null, this._isSliding = !1, this.touchTimeout = null, this._swipeHelper = null, this._indicatorsElement = y.findOne(Sa, this._element), this._addEventListeners(), this._config.ride === ba && this.cycle();
  }
  // Getters
  static get Default() {
    return Da;
  }
  static get DefaultType() {
    return La;
  }
  static get NAME() {
    return ca;
  }
  // Public
  next() {
    this._slide(Pt);
  }
  nextWhenVisible() {
    !document.hidden && Ee(this._element) && this.next();
  }
  prev() {
    this._slide(mt);
  }
  pause() {
    this._isSliding && Es(this._element), this._clearInterval();
  }
  cycle() {
    this._clearInterval(), this._updateInterval(), this._interval = setInterval(() => this.nextWhenVisible(), this._config.interval);
  }
  _maybeEnableCycle() {
    if (this._config.ride) {
      if (this._isSliding) {
        h.one(this._element, Be, () => this.cycle());
        return;
      }
      this.cycle();
    }
  }
  to(t) {
    const e = this._getItems();
    if (t > e.length - 1 || t < 0)
      return;
    if (this._isSliding) {
      h.one(this._element, Be, () => this.to(t));
      return;
    }
    const i = this._getItemIndex(this._getActive());
    if (i === t)
      return;
    const s = t > i ? Pt : mt;
    this._slide(s, e[t]);
  }
  dispose() {
    this._swipeHelper && this._swipeHelper.dispose(), super.dispose();
  }
  // Private
  _configAfterMerge(t) {
    return t.defaultInterval = t.interval, t;
  }
  _addEventListeners() {
    this._config.keyboard && h.on(this._element, _a, (t) => this._keydown(t)), this._config.pause === "hover" && (h.on(this._element, ma, () => this.pause()), h.on(this._element, Ea, () => this._maybeEnableCycle())), this._config.touch && _e.isSupported() && this._addTouchEventListeners();
  }
  _addTouchEventListeners() {
    for (const i of y.find(wa, this._element))
      h.on(i, ga, (s) => s.preventDefault());
    const e = {
      leftCallback: () => this._slide(this._directionToOrder(bt)),
      rightCallback: () => this._slide(this._directionToOrder(ce)),
      endCallback: () => {
        this._config.pause === "hover" && (this.pause(), this.touchTimeout && clearTimeout(this.touchTimeout), this.touchTimeout = setTimeout(
          () => this._maybeEnableCycle(),
          fa + this._config.interval
        ));
      }
    };
    this._swipeHelper = new _e(this._element, e);
  }
  _keydown(t) {
    if (/input|textarea/i.test(t.target.tagName))
      return;
    const e = Oa[t.key];
    e && (t.preventDefault(), this._slide(this._directionToOrder(e)));
  }
  _getItemIndex(t) {
    return this._getItems().indexOf(t);
  }
  _setActiveIndicatorElement(t) {
    if (!this._indicatorsElement)
      return;
    const e = y.findOne(Ps, this._indicatorsElement);
    e.classList.remove(te), e.removeAttribute("aria-current");
    const i = y.findOne(
      `[data-mdb-slide-to="${t}"]`,
      this._indicatorsElement
    );
    i && (i.classList.add(te), i.setAttribute("aria-current", "true"));
  }
  _updateInterval() {
    const t = this._activeElement || this._getActive();
    if (!t)
      return;
    const e = Number.parseInt(t.getAttribute("data-mdb-interval"), 10);
    this._config.interval = e || this._config.defaultInterval;
  }
  _slide(t, e = null) {
    if (this._isSliding)
      return;
    const i = this._getActive(), s = t === Pt, r = e || _n(this._getItems(), i, s, this._config.wrap);
    if (r === i)
      return;
    const o = this._getItemIndex(r), a = (b) => h.trigger(this._element, b, {
      relatedTarget: r,
      direction: this._orderToDirection(t),
      from: this._getItemIndex(i),
      to: o
    });
    if (a(pa).defaultPrevented || !i || !r)
      return;
    const d = !!this._interval;
    this.pause(), this._isSliding = !0, this._setActiveIndicatorElement(o), this._activeElement = r;
    const c = s ? Aa : Ta, f = s ? ya : Na;
    r.classList.add(f), jt(r), i.classList.add(c), r.classList.add(c);
    const g = () => {
      r.classList.remove(c, f), r.classList.add(te), i.classList.remove(te, f, c), this._isSliding = !1, a(Be);
    };
    this._queueCallback(g, i, this._isAnimated()), d && this.cycle();
  }
  _isAnimated() {
    return this._element.classList.contains(va);
  }
  _getActive() {
    return y.findOne(Ca, this._element);
  }
  _getItems() {
    return y.find(ks, this._element);
  }
  _clearInterval() {
    this._interval && (clearInterval(this._interval), this._interval = null);
  }
  _directionToOrder(t) {
    return F() ? t === bt ? mt : Pt : t === bt ? Pt : mt;
  }
  _orderToDirection(t) {
    return F() ? t === mt ? bt : ce : t === mt ? ce : bt;
  }
  // Static
  static jQueryInterface(t) {
    return this.each(function() {
      const e = Hs.getOrCreateInstance(this, t);
      if (typeof t == "number") {
        e.to(t);
        return;
      }
      if (typeof t == "string") {
        if (e[t] === void 0 || t.startsWith("_") || t === "constructor")
          throw new TypeError(`No method named "${t}"`);
        e[t]();
      }
    });
  }
};
const ci = "carousel", Ia = "slide.bs.carousel", Ma = "slid.bs.carousel", Ra = [
  { name: "slide", parametersToCopy: ["relatedTarget", "direction", "from", "to"] },
  { name: "slid", parametersToCopy: ["relatedTarget", "direction", "from", "to"] }
];
class Sh extends $a {
  constructor(t, e) {
    super(t, e), this._init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor);
  }
  dispose() {
    u.off(this._element, Ia), u.off(this._element, Ma), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Getters
  static get NAME() {
    return ci;
  }
  // Private
  _init() {
    this._bindMdbEvents();
  }
  _bindMdbEvents() {
    u.extend(this._element, Ra, ci);
  }
}
const xa = "modal", Pa = "bs.modal", Y = `.${Pa}`, ka = "Escape", Ha = `hide${Y}`, Va = `hidePrevented${Y}`, Ba = `hidden${Y}`, Wa = `show${Y}`, ja = `shown${Y}`, Ka = `resize${Y}`, Fa = `click.dismiss${Y}`, Ua = `mousedown.dismiss${Y}`, Ya = `keydown.dismiss${Y}`, ui = "modal-open", za = "fade", di = "show", We = "modal-static", Ga = ".modal-dialog", qa = ".modal-body", Xa = {
  backdrop: !0,
  focus: !0,
  keyboard: !0
}, Qa = {
  backdrop: "(boolean|string)",
  focus: "boolean",
  keyboard: "boolean"
};
let Za = class Vs extends z {
  constructor(t, e) {
    super(t, e), this._dialog = y.findOne(Ga, this._element), this._backdrop = this._initializeBackDrop(), this._focustrap = this._initializeFocusTrap(), this._isShown = !1, this._isTransitioning = !1, this._scrollBar = new an(), this._addEventListeners();
  }
  // Getters
  static get Default() {
    return Xa;
  }
  static get DefaultType() {
    return Qa;
  }
  static get NAME() {
    return xa;
  }
  // Public
  toggle(t) {
    return this._isShown ? this.hide() : this.show(t);
  }
  show(t) {
    this._isShown || this._isTransitioning || h.trigger(this._element, Wa, {
      relatedTarget: t
    }).defaultPrevented || (this._isShown = !0, this._isTransitioning = !0, this._scrollBar.hide(), document.body.classList.add(ui), this._adjustDialog(), this._backdrop.show(() => this._showElement(t)));
  }
  hide() {
    !this._isShown || this._isTransitioning || h.trigger(this._element, Ha).defaultPrevented || (this._isShown = !1, this._isTransitioning = !0, this._focustrap.deactivate(), this._element.classList.remove(di), this._queueCallback(() => this._hideModal(), this._element, this._isAnimated()));
  }
  dispose() {
    h.off(window, Y), h.off(this._dialog, Y), this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
  }
  handleUpdate() {
    this._adjustDialog();
  }
  // Private
  _initializeBackDrop() {
    return new $s({
      isVisible: !!this._config.backdrop && !this._config.modalNonInvasive,
      // 'static' option will be translated to true, and booleans will keep their value,
      isAnimated: this._isAnimated()
    });
  }
  _initializeFocusTrap() {
    return new Is({
      trapElement: this._element
    });
  }
  _showElement(t) {
    document.body.contains(this._element) || document.body.append(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", !0), this._element.setAttribute("role", "dialog"), this._element.scrollTop = 0;
    const e = y.findOne(qa, this._dialog);
    e && (e.scrollTop = 0), jt(this._element), this._element.classList.add(di);
    const i = () => {
      this._config.focus && this._focustrap.activate(), this._isTransitioning = !1, h.trigger(this._element, ja, {
        relatedTarget: t
      });
    };
    this._queueCallback(i, this._dialog, this._isAnimated());
  }
  _addEventListeners() {
    h.on(this._element, Ya, (t) => {
      if (t.key === ka) {
        if (this._config.keyboard) {
          this.hide();
          return;
        }
        this._triggerBackdropTransition();
      }
    }), h.on(window, Ka, () => {
      this._isShown && !this._isTransitioning && this._adjustDialog();
    }), h.on(this._element, Ua, (t) => {
      h.one(this._element, Fa, (e) => {
        if (!(this._element !== t.target || this._element !== e.target)) {
          if (this._config.backdrop === "static") {
            this._triggerBackdropTransition();
            return;
          }
          this._config.backdrop && this.hide();
        }
      });
    });
  }
  _hideModal() {
    this._element.style.display = "none", this._element.setAttribute("aria-hidden", !0), this._element.removeAttribute("aria-modal"), this._element.removeAttribute("role"), this._isTransitioning = !1, this._backdrop.hide(() => {
      document.body.classList.remove(ui), this._resetAdjustments(), this._scrollBar.reset(), h.trigger(this._element, Ba);
    });
  }
  _isAnimated() {
    return this._element.classList.contains(za);
  }
  _triggerBackdropTransition() {
    if (h.trigger(this._element, Va).defaultPrevented)
      return;
    const e = this._element.scrollHeight > document.documentElement.clientHeight, i = this._element.style.overflowY;
    i === "hidden" || this._element.classList.contains(We) || (e || (this._element.style.overflowY = "hidden"), this._element.classList.add(We), this._queueCallback(() => {
      this._element.classList.remove(We), this._queueCallback(() => {
        this._element.style.overflowY = i;
      }, this._dialog);
    }, this._dialog), this._element.focus());
  }
  /**
   * The following methods are used to handle overflowing modals
   */
  _adjustDialog() {
    const t = this._element.scrollHeight > document.documentElement.clientHeight, e = this._scrollBar.getWidth(), i = e > 0;
    if (i && !t) {
      const s = F() ? "paddingLeft" : "paddingRight";
      this._element.style[s] = `${e}px`;
    }
    if (!i && t) {
      const s = F() ? "paddingRight" : "paddingLeft";
      this._element.style[s] = `${e}px`;
    }
  }
  _resetAdjustments() {
    this._element.style.paddingLeft = "", this._element.style.paddingRight = "";
  }
  // Static
  static jQueryInterface(t, e) {
    return this.each(function() {
      const i = Vs.getOrCreateInstance(this, t);
      if (typeof t == "string") {
        if (typeof i[t] > "u")
          throw new TypeError(`No method named "${t}"`);
        i[t](e);
      }
    });
  }
};
const hi = "modal", Ja = "hide.bs.modal", tl = "hidePrevented.bs.modal", el = "hidden.bs.modal", nl = "show.bs.modal", il = "shown.bs.modal", sl = [
  { name: "show", parametersToCopy: ["relatedTarget"] },
  { name: "shown", parametersToCopy: ["relatedTarget"] },
  { name: "hide" },
  { name: "hidePrevented" },
  { name: "hidden" }
];
class Oh extends Za {
  constructor(t, e) {
    super(t, e), this._init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor);
  }
  dispose() {
    u.off(this._element, nl), u.off(this._element, il), u.off(this._element, Ja), u.off(this._element, el), u.off(this._element, tl), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Getters
  static get NAME() {
    return hi;
  }
  // Private
  _init() {
    this._bindMdbEvents();
  }
  _bindMdbEvents() {
    u.extend(this._element, sl, hi);
  }
}
var x = "top", B = "bottom", W = "right", P = "left", be = "auto", Mt = [x, B, W, P], ht = "start", Ct = "end", Bs = "clippingParents", En = "viewport", vt = "popper", Ws = "reference", ln = /* @__PURE__ */ Mt.reduce(function(n, t) {
  return n.concat([t + "-" + ht, t + "-" + Ct]);
}, []), gn = /* @__PURE__ */ [].concat(Mt, [be]).reduce(function(n, t) {
  return n.concat([t, t + "-" + ht, t + "-" + Ct]);
}, []), js = "beforeRead", Ks = "read", Fs = "afterRead", Us = "beforeMain", Ys = "main", zs = "afterMain", Gs = "beforeWrite", qs = "write", Xs = "afterWrite", Qs = [js, Ks, Fs, Us, Ys, zs, Gs, qs, Xs];
function q(n) {
  return n ? (n.nodeName || "").toLowerCase() : null;
}
function j(n) {
  if (n == null)
    return window;
  if (n.toString() !== "[object Window]") {
    var t = n.ownerDocument;
    return t && t.defaultView || window;
  }
  return n;
}
function ft(n) {
  var t = j(n).Element;
  return n instanceof t || n instanceof Element;
}
function K(n) {
  var t = j(n).HTMLElement;
  return n instanceof t || n instanceof HTMLElement;
}
function bn(n) {
  if (typeof ShadowRoot > "u")
    return !1;
  var t = j(n).ShadowRoot;
  return n instanceof t || n instanceof ShadowRoot;
}
function rl(n) {
  var t = n.state;
  Object.keys(t.elements).forEach(function(e) {
    var i = t.styles[e] || {}, s = t.attributes[e] || {}, r = t.elements[e];
    !K(r) || !q(r) || (Object.assign(r.style, i), Object.keys(s).forEach(function(o) {
      var a = s[o];
      a === !1 ? r.removeAttribute(o) : r.setAttribute(o, a === !0 ? "" : a);
    }));
  });
}
function ol(n) {
  var t = n.state, e = {
    popper: {
      position: t.options.strategy,
      left: "0",
      top: "0",
      margin: "0"
    },
    arrow: {
      position: "absolute"
    },
    reference: {}
  };
  return Object.assign(t.elements.popper.style, e.popper), t.styles = e, t.elements.arrow && Object.assign(t.elements.arrow.style, e.arrow), function() {
    Object.keys(t.elements).forEach(function(i) {
      var s = t.elements[i], r = t.attributes[i] || {}, o = Object.keys(t.styles.hasOwnProperty(i) ? t.styles[i] : e[i]), a = o.reduce(function(l, d) {
        return l[d] = "", l;
      }, {});
      !K(s) || !q(s) || (Object.assign(s.style, a), Object.keys(r).forEach(function(l) {
        s.removeAttribute(l);
      }));
    });
  };
}
const vn = {
  name: "applyStyles",
  enabled: !0,
  phase: "write",
  fn: rl,
  effect: ol,
  requires: ["computeStyles"]
};
function G(n) {
  return n.split("-")[0];
}
var dt = Math.max, me = Math.min, wt = Math.round;
function cn() {
  var n = navigator.userAgentData;
  return n != null && n.brands && Array.isArray(n.brands) ? n.brands.map(function(t) {
    return t.brand + "/" + t.version;
  }).join(" ") : navigator.userAgent;
}
function Zs() {
  return !/^((?!chrome|android).)*safari/i.test(cn());
}
function St(n, t, e) {
  t === void 0 && (t = !1), e === void 0 && (e = !1);
  var i = n.getBoundingClientRect(), s = 1, r = 1;
  t && K(n) && (s = n.offsetWidth > 0 && wt(i.width) / n.offsetWidth || 1, r = n.offsetHeight > 0 && wt(i.height) / n.offsetHeight || 1);
  var o = ft(n) ? j(n) : window, a = o.visualViewport, l = !Zs() && e, d = (i.left + (l && a ? a.offsetLeft : 0)) / s, c = (i.top + (l && a ? a.offsetTop : 0)) / r, f = i.width / s, g = i.height / r;
  return {
    width: f,
    height: g,
    top: c,
    right: d + f,
    bottom: c + g,
    left: d,
    x: d,
    y: c
  };
}
function Tn(n) {
  var t = St(n), e = n.offsetWidth, i = n.offsetHeight;
  return Math.abs(t.width - e) <= 1 && (e = t.width), Math.abs(t.height - i) <= 1 && (i = t.height), {
    x: n.offsetLeft,
    y: n.offsetTop,
    width: e,
    height: i
  };
}
function Js(n, t) {
  var e = t.getRootNode && t.getRootNode();
  if (n.contains(t))
    return !0;
  if (e && bn(e)) {
    var i = t;
    do {
      if (i && n.isSameNode(i))
        return !0;
      i = i.parentNode || i.host;
    } while (i);
  }
  return !1;
}
function Z(n) {
  return j(n).getComputedStyle(n);
}
function al(n) {
  return ["table", "td", "th"].indexOf(q(n)) >= 0;
}
function st(n) {
  return ((ft(n) ? n.ownerDocument : (
    // $FlowFixMe[prop-missing]
    n.document
  )) || window.document).documentElement;
}
function ve(n) {
  return q(n) === "html" ? n : (
    // this is a quicker (but less type safe) way to save quite some bytes from the bundle
    // $FlowFixMe[incompatible-return]
    // $FlowFixMe[prop-missing]
    n.assignedSlot || // step into the shadow DOM of the parent of a slotted node
    n.parentNode || // DOM Element detected
    (bn(n) ? n.host : null) || // ShadowRoot detected
    // $FlowFixMe[incompatible-call]: HTMLElement is a Node
    st(n)
  );
}
function fi(n) {
  return !K(n) || // https://github.com/popperjs/popper-core/issues/837
  Z(n).position === "fixed" ? null : n.offsetParent;
}
function ll(n) {
  var t = /firefox/i.test(cn()), e = /Trident/i.test(cn());
  if (e && K(n)) {
    var i = Z(n);
    if (i.position === "fixed")
      return null;
  }
  var s = ve(n);
  for (bn(s) && (s = s.host); K(s) && ["html", "body"].indexOf(q(s)) < 0; ) {
    var r = Z(s);
    if (r.transform !== "none" || r.perspective !== "none" || r.contain === "paint" || ["transform", "perspective"].indexOf(r.willChange) !== -1 || t && r.willChange === "filter" || t && r.filter && r.filter !== "none")
      return s;
    s = s.parentNode;
  }
  return null;
}
function Ut(n) {
  for (var t = j(n), e = fi(n); e && al(e) && Z(e).position === "static"; )
    e = fi(e);
  return e && (q(e) === "html" || q(e) === "body" && Z(e).position === "static") ? t : e || ll(n) || t;
}
function An(n) {
  return ["top", "bottom"].indexOf(n) >= 0 ? "x" : "y";
}
function Vt(n, t, e) {
  return dt(n, me(t, e));
}
function cl(n, t, e) {
  var i = Vt(n, t, e);
  return i > e ? e : i;
}
function tr() {
  return {
    top: 0,
    right: 0,
    bottom: 0,
    left: 0
  };
}
function er(n) {
  return Object.assign({}, tr(), n);
}
function nr(n, t) {
  return t.reduce(function(e, i) {
    return e[i] = n, e;
  }, {});
}
var ul = function(t, e) {
  return t = typeof t == "function" ? t(Object.assign({}, e.rects, {
    placement: e.placement
  })) : t, er(typeof t != "number" ? t : nr(t, Mt));
};
function dl(n) {
  var t, e = n.state, i = n.name, s = n.options, r = e.elements.arrow, o = e.modifiersData.popperOffsets, a = G(e.placement), l = An(a), d = [P, W].indexOf(a) >= 0, c = d ? "height" : "width";
  if (!(!r || !o)) {
    var f = ul(s.padding, e), g = Tn(r), b = l === "y" ? x : P, O = l === "y" ? B : W, N = e.rects.reference[c] + e.rects.reference[l] - o[l] - e.rects.popper[c], S = o[l] - e.rects.reference[l], D = Ut(r), I = D ? l === "y" ? D.clientHeight || 0 : D.clientWidth || 0 : 0, E = N / 2 - S / 2, p = f[b], m = I - g[c] - f[O], T = I / 2 - g[c] / 2 + E, A = Vt(p, T, m), w = l;
    e.modifiersData[i] = (t = {}, t[w] = A, t.centerOffset = A - T, t);
  }
}
function hl(n) {
  var t = n.state, e = n.options, i = e.element, s = i === void 0 ? "[data-popper-arrow]" : i;
  s != null && (typeof s == "string" && (s = t.elements.popper.querySelector(s), !s) || Js(t.elements.popper, s) && (t.elements.arrow = s));
}
const ir = {
  name: "arrow",
  enabled: !0,
  phase: "main",
  fn: dl,
  effect: hl,
  requires: ["popperOffsets"],
  requiresIfExists: ["preventOverflow"]
};
function Ot(n) {
  return n.split("-")[1];
}
var fl = {
  top: "auto",
  right: "auto",
  bottom: "auto",
  left: "auto"
};
function pl(n, t) {
  var e = n.x, i = n.y, s = t.devicePixelRatio || 1;
  return {
    x: wt(e * s) / s || 0,
    y: wt(i * s) / s || 0
  };
}
function pi(n) {
  var t, e = n.popper, i = n.popperRect, s = n.placement, r = n.variation, o = n.offsets, a = n.position, l = n.gpuAcceleration, d = n.adaptive, c = n.roundOffsets, f = n.isFixed, g = o.x, b = g === void 0 ? 0 : g, O = o.y, N = O === void 0 ? 0 : O, S = typeof c == "function" ? c({
    x: b,
    y: N
  }) : {
    x: b,
    y: N
  };
  b = S.x, N = S.y;
  var D = o.hasOwnProperty("x"), I = o.hasOwnProperty("y"), E = P, p = x, m = window;
  if (d) {
    var T = Ut(e), A = "clientHeight", w = "clientWidth";
    if (T === j(e) && (T = st(e), Z(T).position !== "static" && a === "absolute" && (A = "scrollHeight", w = "scrollWidth")), T = T, s === x || (s === P || s === W) && r === Ct) {
      p = B;
      var C = f && T === m && m.visualViewport ? m.visualViewport.height : (
        // $FlowFixMe[prop-missing]
        T[A]
      );
      N -= C - i.height, N *= l ? 1 : -1;
    }
    if (s === P || (s === x || s === B) && r === Ct) {
      E = W;
      var L = f && T === m && m.visualViewport ? m.visualViewport.width : (
        // $FlowFixMe[prop-missing]
        T[w]
      );
      b -= L - i.width, b *= l ? 1 : -1;
    }
  }
  var $ = Object.assign({
    position: a
  }, d && fl), R = c === !0 ? pl({
    x: b,
    y: N
  }, j(e)) : {
    x: b,
    y: N
  };
  if (b = R.x, N = R.y, l) {
    var M;
    return Object.assign({}, $, (M = {}, M[p] = I ? "0" : "", M[E] = D ? "0" : "", M.transform = (m.devicePixelRatio || 1) <= 1 ? "translate(" + b + "px, " + N + "px)" : "translate3d(" + b + "px, " + N + "px, 0)", M));
  }
  return Object.assign({}, $, (t = {}, t[p] = I ? N + "px" : "", t[E] = D ? b + "px" : "", t.transform = "", t));
}
function _l(n) {
  var t = n.state, e = n.options, i = e.gpuAcceleration, s = i === void 0 ? !0 : i, r = e.adaptive, o = r === void 0 ? !0 : r, a = e.roundOffsets, l = a === void 0 ? !0 : a, d = {
    placement: G(t.placement),
    variation: Ot(t.placement),
    popper: t.elements.popper,
    popperRect: t.rects.popper,
    gpuAcceleration: s,
    isFixed: t.options.strategy === "fixed"
  };
  t.modifiersData.popperOffsets != null && (t.styles.popper = Object.assign({}, t.styles.popper, pi(Object.assign({}, d, {
    offsets: t.modifiersData.popperOffsets,
    position: t.options.strategy,
    adaptive: o,
    roundOffsets: l
  })))), t.modifiersData.arrow != null && (t.styles.arrow = Object.assign({}, t.styles.arrow, pi(Object.assign({}, d, {
    offsets: t.modifiersData.arrow,
    position: "absolute",
    adaptive: !1,
    roundOffsets: l
  })))), t.attributes.popper = Object.assign({}, t.attributes.popper, {
    "data-popper-placement": t.placement
  });
}
const yn = {
  name: "computeStyles",
  enabled: !0,
  phase: "beforeWrite",
  fn: _l,
  data: {}
};
var ee = {
  passive: !0
};
function ml(n) {
  var t = n.state, e = n.instance, i = n.options, s = i.scroll, r = s === void 0 ? !0 : s, o = i.resize, a = o === void 0 ? !0 : o, l = j(t.elements.popper), d = [].concat(t.scrollParents.reference, t.scrollParents.popper);
  return r && d.forEach(function(c) {
    c.addEventListener("scroll", e.update, ee);
  }), a && l.addEventListener("resize", e.update, ee), function() {
    r && d.forEach(function(c) {
      c.removeEventListener("scroll", e.update, ee);
    }), a && l.removeEventListener("resize", e.update, ee);
  };
}
const Nn = {
  name: "eventListeners",
  enabled: !0,
  phase: "write",
  fn: function() {
  },
  effect: ml,
  data: {}
};
var El = {
  left: "right",
  right: "left",
  bottom: "top",
  top: "bottom"
};
function ue(n) {
  return n.replace(/left|right|bottom|top/g, function(t) {
    return El[t];
  });
}
var gl = {
  start: "end",
  end: "start"
};
function _i(n) {
  return n.replace(/start|end/g, function(t) {
    return gl[t];
  });
}
function Cn(n) {
  var t = j(n), e = t.pageXOffset, i = t.pageYOffset;
  return {
    scrollLeft: e,
    scrollTop: i
  };
}
function wn(n) {
  return St(st(n)).left + Cn(n).scrollLeft;
}
function bl(n, t) {
  var e = j(n), i = st(n), s = e.visualViewport, r = i.clientWidth, o = i.clientHeight, a = 0, l = 0;
  if (s) {
    r = s.width, o = s.height;
    var d = Zs();
    (d || !d && t === "fixed") && (a = s.offsetLeft, l = s.offsetTop);
  }
  return {
    width: r,
    height: o,
    x: a + wn(n),
    y: l
  };
}
function vl(n) {
  var t, e = st(n), i = Cn(n), s = (t = n.ownerDocument) == null ? void 0 : t.body, r = dt(e.scrollWidth, e.clientWidth, s ? s.scrollWidth : 0, s ? s.clientWidth : 0), o = dt(e.scrollHeight, e.clientHeight, s ? s.scrollHeight : 0, s ? s.clientHeight : 0), a = -i.scrollLeft + wn(n), l = -i.scrollTop;
  return Z(s || e).direction === "rtl" && (a += dt(e.clientWidth, s ? s.clientWidth : 0) - r), {
    width: r,
    height: o,
    x: a,
    y: l
  };
}
function Sn(n) {
  var t = Z(n), e = t.overflow, i = t.overflowX, s = t.overflowY;
  return /auto|scroll|overlay|hidden/.test(e + s + i);
}
function sr(n) {
  return ["html", "body", "#document"].indexOf(q(n)) >= 0 ? n.ownerDocument.body : K(n) && Sn(n) ? n : sr(ve(n));
}
function Bt(n, t) {
  var e;
  t === void 0 && (t = []);
  var i = sr(n), s = i === ((e = n.ownerDocument) == null ? void 0 : e.body), r = j(i), o = s ? [r].concat(r.visualViewport || [], Sn(i) ? i : []) : i, a = t.concat(o);
  return s ? a : (
    // $FlowFixMe[incompatible-call]: isBody tells us target will be an HTMLElement here
    a.concat(Bt(ve(o)))
  );
}
function un(n) {
  return Object.assign({}, n, {
    left: n.x,
    top: n.y,
    right: n.x + n.width,
    bottom: n.y + n.height
  });
}
function Tl(n, t) {
  var e = St(n, !1, t === "fixed");
  return e.top = e.top + n.clientTop, e.left = e.left + n.clientLeft, e.bottom = e.top + n.clientHeight, e.right = e.left + n.clientWidth, e.width = n.clientWidth, e.height = n.clientHeight, e.x = e.left, e.y = e.top, e;
}
function mi(n, t, e) {
  return t === En ? un(bl(n, e)) : ft(t) ? Tl(t, e) : un(vl(st(n)));
}
function Al(n) {
  var t = Bt(ve(n)), e = ["absolute", "fixed"].indexOf(Z(n).position) >= 0, i = e && K(n) ? Ut(n) : n;
  return ft(i) ? t.filter(function(s) {
    return ft(s) && Js(s, i) && q(s) !== "body";
  }) : [];
}
function yl(n, t, e, i) {
  var s = t === "clippingParents" ? Al(n) : [].concat(t), r = [].concat(s, [e]), o = r[0], a = r.reduce(function(l, d) {
    var c = mi(n, d, i);
    return l.top = dt(c.top, l.top), l.right = me(c.right, l.right), l.bottom = me(c.bottom, l.bottom), l.left = dt(c.left, l.left), l;
  }, mi(n, o, i));
  return a.width = a.right - a.left, a.height = a.bottom - a.top, a.x = a.left, a.y = a.top, a;
}
function rr(n) {
  var t = n.reference, e = n.element, i = n.placement, s = i ? G(i) : null, r = i ? Ot(i) : null, o = t.x + t.width / 2 - e.width / 2, a = t.y + t.height / 2 - e.height / 2, l;
  switch (s) {
    case x:
      l = {
        x: o,
        y: t.y - e.height
      };
      break;
    case B:
      l = {
        x: o,
        y: t.y + t.height
      };
      break;
    case W:
      l = {
        x: t.x + t.width,
        y: a
      };
      break;
    case P:
      l = {
        x: t.x - e.width,
        y: a
      };
      break;
    default:
      l = {
        x: t.x,
        y: t.y
      };
  }
  var d = s ? An(s) : null;
  if (d != null) {
    var c = d === "y" ? "height" : "width";
    switch (r) {
      case ht:
        l[d] = l[d] - (t[c] / 2 - e[c] / 2);
        break;
      case Ct:
        l[d] = l[d] + (t[c] / 2 - e[c] / 2);
        break;
    }
  }
  return l;
}
function Dt(n, t) {
  t === void 0 && (t = {});
  var e = t, i = e.placement, s = i === void 0 ? n.placement : i, r = e.strategy, o = r === void 0 ? n.strategy : r, a = e.boundary, l = a === void 0 ? Bs : a, d = e.rootBoundary, c = d === void 0 ? En : d, f = e.elementContext, g = f === void 0 ? vt : f, b = e.altBoundary, O = b === void 0 ? !1 : b, N = e.padding, S = N === void 0 ? 0 : N, D = er(typeof S != "number" ? S : nr(S, Mt)), I = g === vt ? Ws : vt, E = n.rects.popper, p = n.elements[O ? I : g], m = yl(ft(p) ? p : p.contextElement || st(n.elements.popper), l, c, o), T = St(n.elements.reference), A = rr({
    reference: T,
    element: E,
    strategy: "absolute",
    placement: s
  }), w = un(Object.assign({}, E, A)), C = g === vt ? w : T, L = {
    top: m.top - C.top + D.top,
    bottom: C.bottom - m.bottom + D.bottom,
    left: m.left - C.left + D.left,
    right: C.right - m.right + D.right
  }, $ = n.modifiersData.offset;
  if (g === vt && $) {
    var R = $[s];
    Object.keys(L).forEach(function(M) {
      var ot = [W, B].indexOf(M) >= 0 ? 1 : -1, at = [x, B].indexOf(M) >= 0 ? "y" : "x";
      L[M] += R[at] * ot;
    });
  }
  return L;
}
function Nl(n, t) {
  t === void 0 && (t = {});
  var e = t, i = e.placement, s = e.boundary, r = e.rootBoundary, o = e.padding, a = e.flipVariations, l = e.allowedAutoPlacements, d = l === void 0 ? gn : l, c = Ot(i), f = c ? a ? ln : ln.filter(function(O) {
    return Ot(O) === c;
  }) : Mt, g = f.filter(function(O) {
    return d.indexOf(O) >= 0;
  });
  g.length === 0 && (g = f);
  var b = g.reduce(function(O, N) {
    return O[N] = Dt(n, {
      placement: N,
      boundary: s,
      rootBoundary: r,
      padding: o
    })[G(N)], O;
  }, {});
  return Object.keys(b).sort(function(O, N) {
    return b[O] - b[N];
  });
}
function Cl(n) {
  if (G(n) === be)
    return [];
  var t = ue(n);
  return [_i(n), t, _i(t)];
}
function wl(n) {
  var t = n.state, e = n.options, i = n.name;
  if (!t.modifiersData[i]._skip) {
    for (var s = e.mainAxis, r = s === void 0 ? !0 : s, o = e.altAxis, a = o === void 0 ? !0 : o, l = e.fallbackPlacements, d = e.padding, c = e.boundary, f = e.rootBoundary, g = e.altBoundary, b = e.flipVariations, O = b === void 0 ? !0 : b, N = e.allowedAutoPlacements, S = t.options.placement, D = G(S), I = D === S, E = l || (I || !O ? [ue(S)] : Cl(S)), p = [S].concat(E).reduce(function(pt, J) {
      return pt.concat(G(J) === be ? Nl(t, {
        placement: J,
        boundary: c,
        rootBoundary: f,
        padding: d,
        flipVariations: O,
        allowedAutoPlacements: N
      }) : J);
    }, []), m = t.rects.reference, T = t.rects.popper, A = /* @__PURE__ */ new Map(), w = !0, C = p[0], L = 0; L < p.length; L++) {
      var $ = p[L], R = G($), M = Ot($) === ht, ot = [x, B].indexOf(R) >= 0, at = ot ? "width" : "height", V = Dt(t, {
        placement: $,
        boundary: c,
        rootBoundary: f,
        altBoundary: g,
        padding: d
      }), U = ot ? M ? W : P : M ? B : x;
      m[at] > T[at] && (U = ue(U));
      var zt = ue(U), lt = [];
      if (r && lt.push(V[R] <= 0), a && lt.push(V[U] <= 0, V[zt] <= 0), lt.every(function(pt) {
        return pt;
      })) {
        C = $, w = !1;
        break;
      }
      A.set($, lt);
    }
    if (w)
      for (var Gt = O ? 3 : 1, Se = function(J) {
        var xt = p.find(function(Xt) {
          var ct = A.get(Xt);
          if (ct)
            return ct.slice(0, J).every(function(Oe) {
              return Oe;
            });
        });
        if (xt)
          return C = xt, "break";
      }, Rt = Gt; Rt > 0; Rt--) {
        var qt = Se(Rt);
        if (qt === "break")
          break;
      }
    t.placement !== C && (t.modifiersData[i]._skip = !0, t.placement = C, t.reset = !0);
  }
}
const or = {
  name: "flip",
  enabled: !0,
  phase: "main",
  fn: wl,
  requiresIfExists: ["offset"],
  data: {
    _skip: !1
  }
};
function Ei(n, t, e) {
  return e === void 0 && (e = {
    x: 0,
    y: 0
  }), {
    top: n.top - t.height - e.y,
    right: n.right - t.width + e.x,
    bottom: n.bottom - t.height + e.y,
    left: n.left - t.width - e.x
  };
}
function gi(n) {
  return [x, W, B, P].some(function(t) {
    return n[t] >= 0;
  });
}
function Sl(n) {
  var t = n.state, e = n.name, i = t.rects.reference, s = t.rects.popper, r = t.modifiersData.preventOverflow, o = Dt(t, {
    elementContext: "reference"
  }), a = Dt(t, {
    altBoundary: !0
  }), l = Ei(o, i), d = Ei(a, s, r), c = gi(l), f = gi(d);
  t.modifiersData[e] = {
    referenceClippingOffsets: l,
    popperEscapeOffsets: d,
    isReferenceHidden: c,
    hasPopperEscaped: f
  }, t.attributes.popper = Object.assign({}, t.attributes.popper, {
    "data-popper-reference-hidden": c,
    "data-popper-escaped": f
  });
}
const ar = {
  name: "hide",
  enabled: !0,
  phase: "main",
  requiresIfExists: ["preventOverflow"],
  fn: Sl
};
function Ol(n, t, e) {
  var i = G(n), s = [P, x].indexOf(i) >= 0 ? -1 : 1, r = typeof e == "function" ? e(Object.assign({}, t, {
    placement: n
  })) : e, o = r[0], a = r[1];
  return o = o || 0, a = (a || 0) * s, [P, W].indexOf(i) >= 0 ? {
    x: a,
    y: o
  } : {
    x: o,
    y: a
  };
}
function Dl(n) {
  var t = n.state, e = n.options, i = n.name, s = e.offset, r = s === void 0 ? [0, 0] : s, o = gn.reduce(function(c, f) {
    return c[f] = Ol(f, t.rects, r), c;
  }, {}), a = o[t.placement], l = a.x, d = a.y;
  t.modifiersData.popperOffsets != null && (t.modifiersData.popperOffsets.x += l, t.modifiersData.popperOffsets.y += d), t.modifiersData[i] = o;
}
const lr = {
  name: "offset",
  enabled: !0,
  phase: "main",
  requires: ["popperOffsets"],
  fn: Dl
};
function Ll(n) {
  var t = n.state, e = n.name;
  t.modifiersData[e] = rr({
    reference: t.rects.reference,
    element: t.rects.popper,
    strategy: "absolute",
    placement: t.placement
  });
}
const On = {
  name: "popperOffsets",
  enabled: !0,
  phase: "read",
  fn: Ll,
  data: {}
};
function $l(n) {
  return n === "x" ? "y" : "x";
}
function Il(n) {
  var t = n.state, e = n.options, i = n.name, s = e.mainAxis, r = s === void 0 ? !0 : s, o = e.altAxis, a = o === void 0 ? !1 : o, l = e.boundary, d = e.rootBoundary, c = e.altBoundary, f = e.padding, g = e.tether, b = g === void 0 ? !0 : g, O = e.tetherOffset, N = O === void 0 ? 0 : O, S = Dt(t, {
    boundary: l,
    rootBoundary: d,
    padding: f,
    altBoundary: c
  }), D = G(t.placement), I = Ot(t.placement), E = !I, p = An(D), m = $l(p), T = t.modifiersData.popperOffsets, A = t.rects.reference, w = t.rects.popper, C = typeof N == "function" ? N(Object.assign({}, t.rects, {
    placement: t.placement
  })) : N, L = typeof C == "number" ? {
    mainAxis: C,
    altAxis: C
  } : Object.assign({
    mainAxis: 0,
    altAxis: 0
  }, C), $ = t.modifiersData.offset ? t.modifiersData.offset[t.placement] : null, R = {
    x: 0,
    y: 0
  };
  if (T) {
    if (r) {
      var M, ot = p === "y" ? x : P, at = p === "y" ? B : W, V = p === "y" ? "height" : "width", U = T[p], zt = U + S[ot], lt = U - S[at], Gt = b ? -w[V] / 2 : 0, Se = I === ht ? A[V] : w[V], Rt = I === ht ? -w[V] : -A[V], qt = t.elements.arrow, pt = b && qt ? Tn(qt) : {
        width: 0,
        height: 0
      }, J = t.modifiersData["arrow#persistent"] ? t.modifiersData["arrow#persistent"].padding : tr(), xt = J[ot], Xt = J[at], ct = Vt(0, A[V], pt[V]), Oe = E ? A[V] / 2 - Gt - ct - xt - L.mainAxis : Se - ct - xt - L.mainAxis, Or = E ? -A[V] / 2 + Gt + ct + Xt + L.mainAxis : Rt + ct + Xt + L.mainAxis, De = t.elements.arrow && Ut(t.elements.arrow), Dr = De ? p === "y" ? De.clientTop || 0 : De.clientLeft || 0 : 0, $n = (M = $ == null ? void 0 : $[p]) != null ? M : 0, Lr = U + Oe - $n - Dr, $r = U + Or - $n, In = Vt(b ? me(zt, Lr) : zt, U, b ? dt(lt, $r) : lt);
      T[p] = In, R[p] = In - U;
    }
    if (a) {
      var Mn, Ir = p === "x" ? x : P, Mr = p === "x" ? B : W, ut = T[m], Qt = m === "y" ? "height" : "width", Rn = ut + S[Ir], xn = ut - S[Mr], Le = [x, P].indexOf(D) !== -1, Pn = (Mn = $ == null ? void 0 : $[m]) != null ? Mn : 0, kn = Le ? Rn : ut - A[Qt] - w[Qt] - Pn + L.altAxis, Hn = Le ? ut + A[Qt] + w[Qt] - Pn - L.altAxis : xn, Vn = b && Le ? cl(kn, ut, Hn) : Vt(b ? kn : Rn, ut, b ? Hn : xn);
      T[m] = Vn, R[m] = Vn - ut;
    }
    t.modifiersData[i] = R;
  }
}
const cr = {
  name: "preventOverflow",
  enabled: !0,
  phase: "main",
  fn: Il,
  requiresIfExists: ["offset"]
};
function Ml(n) {
  return {
    scrollLeft: n.scrollLeft,
    scrollTop: n.scrollTop
  };
}
function Rl(n) {
  return n === j(n) || !K(n) ? Cn(n) : Ml(n);
}
function xl(n) {
  var t = n.getBoundingClientRect(), e = wt(t.width) / n.offsetWidth || 1, i = wt(t.height) / n.offsetHeight || 1;
  return e !== 1 || i !== 1;
}
function Pl(n, t, e) {
  e === void 0 && (e = !1);
  var i = K(t), s = K(t) && xl(t), r = st(t), o = St(n, s, e), a = {
    scrollLeft: 0,
    scrollTop: 0
  }, l = {
    x: 0,
    y: 0
  };
  return (i || !i && !e) && ((q(t) !== "body" || // https://github.com/popperjs/popper-core/issues/1078
  Sn(r)) && (a = Rl(t)), K(t) ? (l = St(t, !0), l.x += t.clientLeft, l.y += t.clientTop) : r && (l.x = wn(r))), {
    x: o.left + a.scrollLeft - l.x,
    y: o.top + a.scrollTop - l.y,
    width: o.width,
    height: o.height
  };
}
function kl(n) {
  var t = /* @__PURE__ */ new Map(), e = /* @__PURE__ */ new Set(), i = [];
  n.forEach(function(r) {
    t.set(r.name, r);
  });
  function s(r) {
    e.add(r.name);
    var o = [].concat(r.requires || [], r.requiresIfExists || []);
    o.forEach(function(a) {
      if (!e.has(a)) {
        var l = t.get(a);
        l && s(l);
      }
    }), i.push(r);
  }
  return n.forEach(function(r) {
    e.has(r.name) || s(r);
  }), i;
}
function Hl(n) {
  var t = kl(n);
  return Qs.reduce(function(e, i) {
    return e.concat(t.filter(function(s) {
      return s.phase === i;
    }));
  }, []);
}
function Vl(n) {
  var t;
  return function() {
    return t || (t = new Promise(function(e) {
      Promise.resolve().then(function() {
        t = void 0, e(n());
      });
    })), t;
  };
}
function Bl(n) {
  var t = n.reduce(function(e, i) {
    var s = e[i.name];
    return e[i.name] = s ? Object.assign({}, s, i, {
      options: Object.assign({}, s.options, i.options),
      data: Object.assign({}, s.data, i.data)
    }) : i, e;
  }, {});
  return Object.keys(t).map(function(e) {
    return t[e];
  });
}
var bi = {
  placement: "bottom",
  modifiers: [],
  strategy: "absolute"
};
function vi() {
  for (var n = arguments.length, t = new Array(n), e = 0; e < n; e++)
    t[e] = arguments[e];
  return !t.some(function(i) {
    return !(i && typeof i.getBoundingClientRect == "function");
  });
}
function Te(n) {
  n === void 0 && (n = {});
  var t = n, e = t.defaultModifiers, i = e === void 0 ? [] : e, s = t.defaultOptions, r = s === void 0 ? bi : s;
  return function(a, l, d) {
    d === void 0 && (d = r);
    var c = {
      placement: "bottom",
      orderedModifiers: [],
      options: Object.assign({}, bi, r),
      modifiersData: {},
      elements: {
        reference: a,
        popper: l
      },
      attributes: {},
      styles: {}
    }, f = [], g = !1, b = {
      state: c,
      setOptions: function(D) {
        var I = typeof D == "function" ? D(c.options) : D;
        N(), c.options = Object.assign({}, r, c.options, I), c.scrollParents = {
          reference: ft(a) ? Bt(a) : a.contextElement ? Bt(a.contextElement) : [],
          popper: Bt(l)
        };
        var E = Hl(Bl([].concat(i, c.options.modifiers)));
        return c.orderedModifiers = E.filter(function(p) {
          return p.enabled;
        }), O(), b.update();
      },
      // Sync update – it will always be executed, even if not necessary. This
      // is useful for low frequency updates where sync behavior simplifies the
      // logic.
      // For high frequency updates (e.g. `resize` and `scroll` events), always
      // prefer the async Popper#update method
      forceUpdate: function() {
        if (!g) {
          var D = c.elements, I = D.reference, E = D.popper;
          if (vi(I, E)) {
            c.rects = {
              reference: Pl(I, Ut(E), c.options.strategy === "fixed"),
              popper: Tn(E)
            }, c.reset = !1, c.placement = c.options.placement, c.orderedModifiers.forEach(function(L) {
              return c.modifiersData[L.name] = Object.assign({}, L.data);
            });
            for (var p = 0; p < c.orderedModifiers.length; p++) {
              if (c.reset === !0) {
                c.reset = !1, p = -1;
                continue;
              }
              var m = c.orderedModifiers[p], T = m.fn, A = m.options, w = A === void 0 ? {} : A, C = m.name;
              typeof T == "function" && (c = T({
                state: c,
                options: w,
                name: C,
                instance: b
              }) || c);
            }
          }
        }
      },
      // Async and optimistically optimized update – it will not be executed if
      // not necessary (debounced to run at most once-per-tick)
      update: Vl(function() {
        return new Promise(function(S) {
          b.forceUpdate(), S(c);
        });
      }),
      destroy: function() {
        N(), g = !0;
      }
    };
    if (!vi(a, l))
      return b;
    b.setOptions(d).then(function(S) {
      !g && d.onFirstUpdate && d.onFirstUpdate(S);
    });
    function O() {
      c.orderedModifiers.forEach(function(S) {
        var D = S.name, I = S.options, E = I === void 0 ? {} : I, p = S.effect;
        if (typeof p == "function") {
          var m = p({
            state: c,
            name: D,
            instance: b,
            options: E
          }), T = function() {
          };
          f.push(m || T);
        }
      });
    }
    function N() {
      f.forEach(function(S) {
        return S();
      }), f = [];
    }
    return b;
  };
}
var Wl = /* @__PURE__ */ Te(), jl = [Nn, On, yn, vn], Kl = /* @__PURE__ */ Te({
  defaultModifiers: jl
}), Fl = [Nn, On, yn, vn, lr, or, cr, ir, ar], Dn = /* @__PURE__ */ Te({
  defaultModifiers: Fl
});
const ur = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  afterMain: zs,
  afterRead: Fs,
  afterWrite: Xs,
  applyStyles: vn,
  arrow: ir,
  auto: be,
  basePlacements: Mt,
  beforeMain: Us,
  beforeRead: js,
  beforeWrite: Gs,
  bottom: B,
  clippingParents: Bs,
  computeStyles: yn,
  createPopper: Dn,
  createPopperBase: Wl,
  createPopperLite: Kl,
  detectOverflow: Dt,
  end: Ct,
  eventListeners: Nn,
  flip: or,
  hide: ar,
  left: P,
  main: Ys,
  modifierPhases: Qs,
  offset: lr,
  placements: gn,
  popper: vt,
  popperGenerator: Te,
  popperOffsets: On,
  preventOverflow: cr,
  read: Ks,
  reference: Ws,
  right: W,
  start: ht,
  top: x,
  variationPlacements: ln,
  viewport: En,
  write: qs
}, Symbol.toStringTag, { value: "Module" })), Ul = /^aria-[\w-]*$/i, dr = {
  // Global attributes allowed on any supplied element below.
  "*": ["class", "dir", "id", "lang", "role", Ul],
  a: ["target", "href", "title", "rel"],
  area: [],
  b: [],
  br: [],
  col: [],
  code: [],
  div: [],
  em: [],
  hr: [],
  h1: [],
  h2: [],
  h3: [],
  h4: [],
  h5: [],
  h6: [],
  i: [],
  img: ["src", "srcset", "alt", "title", "width", "height"],
  li: [],
  ol: [],
  p: [],
  pre: [],
  s: [],
  small: [],
  span: [],
  sub: [],
  sup: [],
  strong: [],
  u: [],
  ul: []
}, Yl = /* @__PURE__ */ new Set([
  "background",
  "cite",
  "href",
  "itemtype",
  "longdesc",
  "poster",
  "src",
  "xlink:href"
]), zl = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:/?#]*(?:[/?#]|$))/i, Gl = (n, t) => {
  const e = n.nodeName.toLowerCase();
  return t.includes(e) ? Yl.has(e) ? !!zl.test(n.nodeValue) : !0 : t.filter((i) => i instanceof RegExp).some((i) => i.test(e));
};
function ql(n, t, e) {
  if (!n.length)
    return n;
  if (e && typeof e == "function")
    return e(n);
  const s = new window.DOMParser().parseFromString(n, "text/html"), r = [].concat(...s.body.querySelectorAll("*"));
  for (const o of r) {
    const a = o.nodeName.toLowerCase();
    if (!Object.keys(t).includes(a)) {
      o.remove();
      continue;
    }
    const l = [].concat(...o.attributes), d = [].concat(t["*"] || [], t[a] || []);
    for (const c of l)
      Gl(c, d) || o.removeAttribute(c.nodeName);
  }
  return s.body.innerHTML;
}
const Xl = "TemplateFactory", Ql = {
  allowList: dr,
  content: {},
  // { selector : text ,  selector2 : text2 , }
  extraClass: "",
  html: !1,
  sanitize: !0,
  sanitizeFn: null,
  template: "<div></div>"
}, Zl = {
  allowList: "object",
  content: "object",
  extraClass: "(string|function)",
  html: "boolean",
  sanitize: "boolean",
  sanitizeFn: "(null|function)",
  template: "string"
}, Jl = {
  entry: "(string|element|function|null)",
  selector: "(string|element)"
};
class tc extends Kt {
  constructor(t) {
    super(), this._config = this._getConfig(t);
  }
  // Getters
  static get Default() {
    return Ql;
  }
  static get DefaultType() {
    return Zl;
  }
  static get NAME() {
    return Xl;
  }
  // Public
  getContent() {
    return Object.values(this._config.content).map((t) => this._resolvePossibleFunction(t)).filter(Boolean);
  }
  hasContent() {
    return this.getContent().length > 0;
  }
  changeContent(t) {
    return this._checkContent(t), this._config.content = { ...this._config.content, ...t }, this;
  }
  toHtml() {
    const t = document.createElement("div");
    t.innerHTML = this._maybeSanitize(this._config.template);
    for (const [s, r] of Object.entries(this._config.content))
      this._setContent(t, r, s);
    const e = t.children[0], i = this._resolvePossibleFunction(this._config.extraClass);
    return i && e.classList.add(...i.split(" ")), e;
  }
  // Private
  _typeCheckConfig(t) {
    super._typeCheckConfig(t), this._checkContent(t.content);
  }
  _checkContent(t) {
    for (const [e, i] of Object.entries(t))
      super._typeCheckConfig({ selector: e, entry: i }, Jl);
  }
  _setContent(t, e, i) {
    const s = y.findOne(i, t);
    if (s) {
      if (e = this._resolvePossibleFunction(e), !e) {
        s.remove();
        return;
      }
      if (Q(e)) {
        this._putElementInTemplate(it(e), s);
        return;
      }
      if (this._config.html) {
        s.innerHTML = this._maybeSanitize(e);
        return;
      }
      s.textContent = e;
    }
  }
  _maybeSanitize(t) {
    return this._config.sanitize ? ql(t, this._config.allowList, this._config.sanitizeFn) : t;
  }
  _resolvePossibleFunction(t) {
    return k(t, [this]);
  }
  _putElementInTemplate(t, e) {
    if (this._config.html) {
      e.innerHTML = "", e.append(t);
      return;
    }
    e.textContent = t.textContent;
  }
}
const ec = "tooltip", nc = /* @__PURE__ */ new Set(["sanitize", "allowList", "sanitizeFn"]), je = "fade", ic = "modal", ne = "show", sc = ".tooltip-inner", Ti = `.${ic}`, Ai = "hide.bs.modal", kt = "hover", Ke = "focus", rc = "click", oc = "manual", ac = "hide", lc = "hidden", cc = "show", uc = "shown", dc = "inserted", hc = "click", fc = "focusin", pc = "focusout", _c = "mouseenter", mc = "mouseleave", Ec = {
  AUTO: "auto",
  TOP: "top",
  RIGHT: F() ? "left" : "right",
  BOTTOM: "bottom",
  LEFT: F() ? "right" : "left"
}, gc = {
  allowList: dr,
  animation: !0,
  boundary: "clippingParents",
  container: !1,
  customClass: "",
  delay: 0,
  fallbackPlacements: ["top", "right", "bottom", "left"],
  html: !1,
  offset: [0, 6],
  placement: "top",
  popperConfig: null,
  sanitize: !0,
  sanitizeFn: null,
  selector: !1,
  template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
  title: "",
  trigger: "hover focus"
}, bc = {
  allowList: "object",
  animation: "boolean",
  boundary: "(string|element)",
  container: "(string|element|boolean)",
  customClass: "(string|function)",
  delay: "(number|object)",
  fallbackPlacements: "array",
  html: "boolean",
  offset: "(array|string|function)",
  placement: "(string|function)",
  popperConfig: "(null|object|function)",
  sanitize: "boolean",
  sanitizeFn: "(null|function)",
  selector: "(string|boolean)",
  template: "string",
  title: "(string|element|function)",
  trigger: "string"
};
let Ae = class hr extends z {
  constructor(t, e) {
    if (typeof ur > "u")
      throw new TypeError("Bootstrap's tooltips require Popper (https://popper.js.org)");
    super(t, e), this._isEnabled = !0, this._timeout = 0, this._isHovered = null, this._activeTrigger = {}, this._popper = null, this._templateFactory = null, this._newContent = null, this.tip = null, this._setListeners(), this._config.selector || this._fixTitle();
  }
  // Getters
  static get Default() {
    return gc;
  }
  static get DefaultType() {
    return bc;
  }
  static get NAME() {
    return ec;
  }
  // Public
  enable() {
    this._isEnabled = !0;
  }
  disable() {
    this._isEnabled = !1;
  }
  toggleEnabled() {
    this._isEnabled = !this._isEnabled;
  }
  toggle() {
    if (this._isEnabled) {
      if (this._activeTrigger.click = !this._activeTrigger.click, this._isShown()) {
        this._leave();
        return;
      }
      this._enter();
    }
  }
  dispose() {
    clearTimeout(this._timeout), h.off(
      this._element.closest(Ti),
      Ai,
      this._hideModalHandler
    ), this._element.getAttribute("data-mdb-original-title") && this._element.setAttribute("title", this._element.getAttribute("data-mdb-original-title")), this._disposePopper(), super.dispose();
  }
  show() {
    if (this._element.style.display === "none")
      throw new Error("Please use show on visible elements");
    if (!(this._isWithContent() && this._isEnabled))
      return;
    const t = h.trigger(this._element, this.constructor.eventName(cc)), i = (gs(this._element) || this._element.ownerDocument.documentElement).contains(
      this._element
    );
    if (t.defaultPrevented || !i)
      return;
    this._disposePopper();
    const s = this._getTipElement();
    this._element.setAttribute("aria-describedby", s.getAttribute("id"));
    const { container: r } = this._config;
    if (this._element.ownerDocument.documentElement.contains(this.tip) || (r.append(s), h.trigger(this._element, this.constructor.eventName(dc))), this._popper = this._createPopper(s), s.classList.add(ne), "ontouchstart" in document.documentElement)
      for (const a of [].concat(...document.body.children))
        h.on(a, "mouseover", he);
    const o = () => {
      h.trigger(this._element, this.constructor.eventName(uc)), this._isHovered === !1 && this._leave(), this._isHovered = !1;
    };
    this._queueCallback(o, this.tip, this._isAnimated());
  }
  hide() {
    if (!this._isShown() || h.trigger(this._element, this.constructor.eventName(ac)).defaultPrevented)
      return;
    if (this._getTipElement().classList.remove(ne), "ontouchstart" in document.documentElement)
      for (const s of [].concat(...document.body.children))
        h.off(s, "mouseover", he);
    this._activeTrigger[rc] = !1, this._activeTrigger[Ke] = !1, this._activeTrigger[kt] = !1, this._isHovered = null;
    const i = () => {
      this._isWithActiveTrigger() || (this._isHovered || this._disposePopper(), this._element.removeAttribute("aria-describedby"), h.trigger(this._element, this.constructor.eventName(lc)));
    };
    this._queueCallback(i, this.tip, this._isAnimated());
  }
  update() {
    this._popper && this._popper.update();
  }
  // Protected
  _isWithContent() {
    return !!this._getTitle();
  }
  _getTipElement() {
    return this.tip || (this.tip = this._createTipElement(this._newContent || this._getContentForTemplate())), this.tip;
  }
  _createTipElement(t) {
    const e = this._getTemplateFactory(t).toHtml();
    if (!e)
      return null;
    e.classList.remove(je, ne), e.classList.add(`bs-${this.constructor.NAME}-auto`);
    const i = Gr(this.constructor.NAME).toString();
    return e.setAttribute("id", i), this._isAnimated() && e.classList.add(je), e;
  }
  setContent(t) {
    this._newContent = t, this._isShown() && (this._disposePopper(), this.show());
  }
  _getTemplateFactory(t) {
    return this._templateFactory ? this._templateFactory.changeContent(t) : this._templateFactory = new tc({
      ...this._config,
      // the `content` var has to be after `this._config`
      // to override config.content in case of popover
      content: t,
      extraClass: this._resolvePossibleFunction(this._config.customClass)
    }), this._templateFactory;
  }
  _getContentForTemplate() {
    return {
      [sc]: this._getTitle()
    };
  }
  _getTitle() {
    return this._resolvePossibleFunction(this._config.title) || this._element.getAttribute("data-mdb-original-title");
  }
  // Private
  _initializeOnDelegatedTarget(t) {
    return this.constructor.getOrCreateInstance(t.delegateTarget, this._getDelegateConfig());
  }
  _isAnimated() {
    return this._config.animation || this.tip && this.tip.classList.contains(je);
  }
  _isShown() {
    return this.tip && this.tip.classList.contains(ne);
  }
  _createPopper(t) {
    const e = k(this._config.placement, [this, t, this._element]), i = Ec[e.toUpperCase()];
    return Dn(this._element, t, this._getPopperConfig(i));
  }
  _getOffset() {
    const { offset: t } = this._config;
    return typeof t == "string" ? t.split(",").map((e) => Number.parseInt(e, 10)) : typeof t == "function" ? (e) => t(e, this._element) : t;
  }
  _resolvePossibleFunction(t) {
    return k(t, [this._element]);
  }
  _getPopperConfig(t) {
    const e = {
      placement: t,
      modifiers: [
        {
          name: "flip",
          options: {
            fallbackPlacements: this._config.fallbackPlacements
          }
        },
        {
          name: "offset",
          options: {
            offset: this._getOffset()
          }
        },
        {
          name: "preventOverflow",
          options: {
            boundary: this._config.boundary
          }
        },
        {
          name: "arrow",
          options: {
            element: `.${this.constructor.NAME}-arrow`
          }
        },
        {
          name: "preSetPlacement",
          enabled: !0,
          phase: "beforeMain",
          fn: (i) => {
            this._getTipElement().setAttribute("data-popper-placement", i.state.placement);
          }
        }
      ]
    };
    return {
      ...e,
      ...k(this._config.popperConfig, [e])
    };
  }
  _setListeners() {
    const t = this._config.trigger.split(" ");
    for (const e of t)
      if (e === "click")
        h.on(
          this._element,
          this.constructor.eventName(hc),
          this._config.selector,
          (i) => {
            this._initializeOnDelegatedTarget(i).toggle();
          }
        );
      else if (e !== oc) {
        const i = e === kt ? this.constructor.eventName(_c) : this.constructor.eventName(fc), s = e === kt ? this.constructor.eventName(mc) : this.constructor.eventName(pc);
        h.on(this._element, i, this._config.selector, (r) => {
          const o = this._initializeOnDelegatedTarget(r);
          o._activeTrigger[r.type === "focusin" ? Ke : kt] = !0, o._enter();
        }), h.on(this._element, s, this._config.selector, (r) => {
          const o = this._initializeOnDelegatedTarget(r);
          o._activeTrigger[r.type === "focusout" ? Ke : kt] = o._element.contains(r.relatedTarget), o._leave();
        });
      }
    this._hideModalHandler = () => {
      this._element && this.hide();
    }, h.on(
      this._element.closest(Ti),
      Ai,
      this._hideModalHandler
    );
  }
  _fixTitle() {
    const t = this._element.getAttribute("title");
    t && (!this._element.getAttribute("aria-label") && !this._element.textContent.trim() && this._element.setAttribute("aria-label", t), this._element.setAttribute("data-mdb-original-title", t), this._element.removeAttribute("title"));
  }
  _enter() {
    if (this._isShown() || this._isHovered) {
      this._isHovered = !0;
      return;
    }
    this._isHovered = !0, this._setTimeout(() => {
      this._isHovered && this.show();
    }, this._config.delay.show);
  }
  _leave() {
    this._isWithActiveTrigger() || (this._isHovered = !1, this._setTimeout(() => {
      this._isHovered || this.hide();
    }, this._config.delay.hide));
  }
  _setTimeout(t, e) {
    clearTimeout(this._timeout), this._timeout = setTimeout(t, e);
  }
  _isWithActiveTrigger() {
    return Object.values(this._activeTrigger).includes(!0);
  }
  _getConfig(t) {
    const e = nt.getDataAttributes(this._element);
    for (const i of Object.keys(e))
      nc.has(i) && delete e[i];
    return t = {
      ...e,
      ...typeof t == "object" && t ? t : {}
    }, t = this._mergeConfigObj(t), t = this._configAfterMerge(t), this._typeCheckConfig(t), t;
  }
  _configAfterMerge(t) {
    return t.container = t.container === !1 ? document.body : it(t.container), typeof t.delay == "number" && (t.delay = {
      show: t.delay,
      hide: t.delay
    }), typeof t.title == "number" && (t.title = t.title.toString()), typeof t.content == "number" && (t.content = t.content.toString()), t;
  }
  _getDelegateConfig() {
    const t = {};
    for (const [e, i] of Object.entries(this._config))
      this.constructor.Default[e] !== i && (t[e] = i);
    return t.selector = !1, t.trigger = "manual", t;
  }
  _disposePopper() {
    this._popper && (this._popper.destroy(), this._popper = null), this.tip && (this.tip.remove(), this.tip = null);
  }
  // Static
  static jQueryInterface(t) {
    return this.each(function() {
      const e = hr.getOrCreateInstance(this, t);
      if (typeof t == "string") {
        if (typeof e[t] > "u")
          throw new TypeError(`No method named "${t}"`);
        e[t]();
      }
    });
  }
};
const vc = "popover", Tc = ".popover-header", Ac = ".popover-body", yc = {
  ...Ae.Default,
  content: "",
  offset: [0, 8],
  placement: "right",
  template: '<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>',
  trigger: "click"
}, Nc = {
  ...Ae.DefaultType,
  content: "(null|string|element|function)"
};
let Cc = class fr extends Ae {
  // Getters
  static get Default() {
    return yc;
  }
  static get DefaultType() {
    return Nc;
  }
  static get NAME() {
    return vc;
  }
  // Overrides
  _isWithContent() {
    return this._getTitle() || this._getContent();
  }
  // Private
  _getContentForTemplate() {
    return {
      [Tc]: this._getTitle(),
      [Ac]: this._getContent()
    };
  }
  _getContent() {
    return this._resolvePossibleFunction(this._config.content);
  }
  // Static
  static jQueryInterface(t) {
    return this.each(function() {
      const e = fr.getOrCreateInstance(this, t);
      if (typeof t == "string") {
        if (typeof e[t] > "u")
          throw new TypeError(`No method named "${t}"`);
        e[t]();
      }
    });
  }
};
const yi = "popover", wc = "show.bs.popover", Sc = "shown.bs.popover", Oc = "hide.bs.popover", Dc = "hidden.bs.popover", Lc = "inserted.bs.popover", $c = [
  { name: "show" },
  { name: "shown" },
  { name: "hide" },
  { name: "hidden" },
  { name: "inserted" }
];
class Dh extends Cc {
  constructor(t, e) {
    super(t, e), this._init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor);
  }
  dispose() {
    u.off(this.element, wc), u.off(this.element, Sc), u.off(this.element, Oc), u.off(this.element, Dc), u.off(this.element, Lc), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Getters
  static get NAME() {
    return yi;
  }
  // Private
  _init() {
    this._bindMdbEvents();
  }
  _bindMdbEvents() {
    u.extend(this._element, $c, yi);
  }
}
const Ic = "scrollspy", Mc = "bs.scrollspy", pr = `.${Mc}`, Rc = `activate${pr}`, Ni = `click${pr}`, xc = "dropdown-item", Et = "active", Fe = "[href]", Pc = ".nav, .list-group", Ci = ".nav-link", kc = ".nav-item", Hc = ".list-group-item", Vc = `${Ci}, ${kc} > ${Ci}, ${Hc}`, Bc = ".dropdown", Wc = ".dropdown-toggle", jc = {
  offset: null,
  // TODO: v6 @deprecated, keep it for backwards compatibility reasons
  rootMargin: "0px 0px -25%",
  smoothScroll: !1,
  target: null,
  threshold: [0.1, 0.5, 1]
}, Kc = {
  offset: "(number|null)",
  // TODO v6 @deprecated, keep it for backwards compatibility reasons
  rootMargin: "string",
  smoothScroll: "boolean",
  target: "element",
  threshold: "array"
};
let Fc = class _r extends z {
  constructor(t, e) {
    super(t, e), this._config.target && (this._targetLinks = /* @__PURE__ */ new Map(), this._observableSections = /* @__PURE__ */ new Map(), this._rootElement = getComputedStyle(this._element).overflowY === "visible" ? null : this._element, this._activeTarget = null, this._observer = null, this._previousScrollData = {
      visibleEntryTop: 0,
      parentScrollTop: 0
    }, this.refresh());
  }
  // Getters
  static get Default() {
    return jc;
  }
  static get DefaultType() {
    return Kc;
  }
  static get NAME() {
    return Ic;
  }
  // Public
  refresh() {
    this._initializeTargetsAndObservables(), this._maybeEnableSmoothScroll(), this._observer ? this._observer.disconnect() : this._observer = this._getNewObserver();
    for (const t of this._observableSections.values())
      this._observer.observe(t);
  }
  dispose() {
    this._observer && this._observer.disconnect(), super.dispose();
  }
  // Private
  _configAfterMerge(t) {
    return t.target = it(t.target) || document.body, t.rootMargin = t.offset ? `${t.offset}px 0px -30%` : t.rootMargin, typeof t.threshold == "string" && (t.threshold = t.threshold.split(",").map((e) => Number.parseFloat(e))), t;
  }
  _maybeEnableSmoothScroll() {
    this._config.smoothScroll && (h.off(this._config.target, Ni), h.on(this._config.target, Ni, Fe, (t) => {
      const e = this._observableSections.get(t.target.hash);
      if (e) {
        t.preventDefault();
        const i = this._rootElement || window, s = e.offsetTop - this._element.offsetTop;
        if (i.scrollTo) {
          i.scrollTo({ top: s, behavior: "smooth" });
          return;
        }
        i.scrollTop = s;
      }
    }));
  }
  _getNewObserver() {
    const t = {
      root: this._rootElement,
      threshold: this._config.threshold,
      rootMargin: this._config.rootMargin
    };
    return new IntersectionObserver((e) => this._observerCallback(e), t);
  }
  // The logic of selection
  _observerCallback(t) {
    const e = (o) => this._targetLinks.get(`#${o.target.id}`), i = (o) => {
      this._previousScrollData.visibleEntryTop = o.target.offsetTop, this._process(e(o));
    }, s = (this._rootElement || document.documentElement).scrollTop, r = s >= this._previousScrollData.parentScrollTop;
    this._previousScrollData.parentScrollTop = s;
    for (const o of t) {
      if (!o.isIntersecting) {
        this._activeTarget = null, this._clearActiveClass(e(o));
        continue;
      }
      const a = o.target.offsetTop >= this._previousScrollData.visibleEntryTop;
      if (r && a) {
        if (i(o), !s)
          return;
        continue;
      }
      !r && !a && i(o);
    }
  }
  _initializeTargetsAndObservables() {
    this._targetLinks = /* @__PURE__ */ new Map(), this._observableSections = /* @__PURE__ */ new Map();
    const t = y.find(Fe, this._config.target);
    for (const e of t) {
      if (!e.hash || Nt(e))
        continue;
      const i = y.findOne(decodeURI(e.hash), this._element);
      Ee(i) && (this._targetLinks.set(decodeURI(e.hash), e), this._observableSections.set(e.hash, i));
    }
  }
  _process(t) {
    this._activeTarget !== t && (this._clearActiveClass(this._config.target), this._activeTarget = t, t.classList.add(Et), this._activateParents(t), h.trigger(this._element, Rc, { relatedTarget: t }));
  }
  _activateParents(t) {
    if (t.classList.contains(xc)) {
      y.findOne(
        Wc,
        t.closest(Bc)
      ).classList.add(Et);
      return;
    }
    for (const e of y.parents(t, Pc))
      for (const i of y.prev(e, Vc))
        i.classList.add(Et);
  }
  _clearActiveClass(t) {
    t.classList.remove(Et);
    const e = y.find(
      `${Fe}.${Et}`,
      t
    );
    for (const i of e)
      i.classList.remove(Et);
  }
  // Static
  static jQueryInterface(t) {
    return this.each(function() {
      const e = _r.getOrCreateInstance(this, t);
      if (typeof t == "string") {
        if (e[t] === void 0 || t.startsWith("_") || t === "constructor")
          throw new TypeError(`No method named "${t}"`);
        e[t]();
      }
    });
  }
};
const mr = "scrollspy", Uc = `mdb.${mr}`, Yc = `.${Uc}`, wi = "activate.bs.scrollspy", zc = `activate${Yc}`, Er = "collapsible-scrollspy", Gc = "active", Ue = "ul", qc = `.${Gc}`, Si = `.${Er}`;
class Lh extends Fc {
  constructor(t, e) {
    super(t, e), this._collapsibles = [], this._init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor);
  }
  dispose() {
    u.off(this._scrollElement, wi), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Getters
  static get NAME() {
    return mr;
  }
  // Private
  _init() {
    this._bindActivateEvent(), this._getCollapsibles(), this._collapsibles.length !== 0 && (this._showSubsection(), this._hideSubsection());
  }
  _getHeight(t) {
    return t.offsetHeight;
  }
  _hide(t) {
    const e = v.findOne(Ue, t.parentNode);
    e.style.overflow = "hidden", e.style.height = "0px";
  }
  _show(t, e) {
    t.style.height = e;
  }
  _getCollapsibles() {
    const t = v.find(Si);
    t && t.forEach((e) => {
      const i = e.parentNode, s = v.findOne(Ue, i), r = s.offsetHeight;
      this._collapsibles.push({
        element: s,
        relatedTarget: e.getAttribute("href"),
        height: `${r}px`
      });
    });
  }
  _showSubsection() {
    v.find(qc).filter((i) => _.hasClass(i, Er)).forEach((i) => {
      const s = v.findOne(Ue, i.parentNode), r = this._collapsibles.find((o) => o.relatedTarget = i.getAttribute("href")).height;
      this._show(s, r);
    });
  }
  _hideSubsection() {
    v.find(Si).filter((e) => _.hasClass(e, "active") === !1).forEach((e) => {
      this._hide(e);
    });
  }
  _bindActivateEvent() {
    u.on(this._element, wi, (t) => {
      this._showSubsection(), this._hideSubsection(), u.trigger(this._element, zc, {
        relatedTarget: t.relatedTarget
      });
    });
  }
}
const Xc = "tab", Qc = "bs.tab", Yt = `.${Qc}`, Zc = `hide${Yt}`, Jc = `hidden${Yt}`, tu = `show${Yt}`, eu = `shown${Yt}`, nu = `keydown${Yt}`, iu = "ArrowLeft", Oi = "ArrowRight", su = "ArrowUp", Di = "ArrowDown", Ye = "Home", Li = "End", ie = "active", $i = "fade", ze = "show", ru = "dropdown", gr = ".dropdown-toggle", ou = ".dropdown-menu", Ge = `:not(${gr})`, au = '.list-group, .nav, [role="tablist"]', lu = ".nav-item, .list-group-item", cu = `.nav-link${Ge}, .list-group-item${Ge}, [role="tab"]${Ge}`, uu = "[data-mdb-tab-initialized]", qe = `${cu}, ${uu}`;
let du = class dn extends z {
  constructor(t) {
    super(t), this._parent = this._element.closest(au), this._parent && (this._setInitialAttributes(this._parent, this._getChildren()), h.on(this._element, nu, (e) => this._keydown(e)));
  }
  // Getters
  static get NAME() {
    return Xc;
  }
  // Public
  show() {
    const t = this._element;
    if (this._elemIsActive(t))
      return;
    const e = this._getActiveElem(), i = e ? h.trigger(e, Zc, { relatedTarget: t }) : null;
    h.trigger(t, tu, { relatedTarget: e }).defaultPrevented || i && i.defaultPrevented || (this._deactivate(e, t), this._activate(t, e));
  }
  // Private
  _activate(t, e) {
    if (!t)
      return;
    t.classList.add(ie), this._activate(y.getElementFromSelector(t));
    const i = () => {
      if (t.getAttribute("role") !== "tab") {
        t.classList.add(ze);
        return;
      }
      t.removeAttribute("tabindex"), t.setAttribute("aria-selected", !0), this._toggleDropDown(t, !0), h.trigger(t, eu, {
        relatedTarget: e
      });
    };
    this._queueCallback(i, t, t.classList.contains($i));
  }
  _deactivate(t, e) {
    if (!t)
      return;
    t.classList.remove(ie), t.blur(), this._deactivate(y.getElementFromSelector(t));
    const i = () => {
      if (t.getAttribute("role") !== "tab") {
        t.classList.remove(ze);
        return;
      }
      t.setAttribute("aria-selected", !1), t.setAttribute("tabindex", "-1"), this._toggleDropDown(t, !1), h.trigger(t, Jc, { relatedTarget: e });
    };
    this._queueCallback(i, t, t.classList.contains($i));
  }
  _keydown(t) {
    if (![iu, Oi, su, Di, Ye, Li].includes(
      t.key
    ))
      return;
    t.stopPropagation(), t.preventDefault();
    const e = this._getChildren().filter((s) => !Nt(s));
    let i;
    if ([Ye, Li].includes(t.key))
      i = e[t.key === Ye ? 0 : e.length - 1];
    else {
      const s = [Oi, Di].includes(t.key);
      i = _n(e, t.target, s, !0);
    }
    i && (i.focus({ preventScroll: !0 }), dn.getOrCreateInstance(i).show());
  }
  _getChildren() {
    return y.find(qe, this._parent);
  }
  _getActiveElem() {
    return this._getChildren().find((t) => this._elemIsActive(t)) || null;
  }
  _setInitialAttributes(t, e) {
    this._setAttributeIfNotExists(t, "role", "tablist");
    for (const i of e)
      this._setInitialAttributesOnChild(i);
  }
  _setInitialAttributesOnChild(t) {
    t = this._getInnerElement(t);
    const e = this._elemIsActive(t), i = this._getOuterElement(t);
    t.setAttribute("aria-selected", e), i !== t && this._setAttributeIfNotExists(i, "role", "presentation"), e || t.setAttribute("tabindex", "-1"), this._setAttributeIfNotExists(t, "role", "tab"), this._setInitialAttributesOnTargetPanel(t);
  }
  _setInitialAttributesOnTargetPanel(t) {
    const e = y.getElementFromSelector(t);
    e && (this._setAttributeIfNotExists(e, "role", "tabpanel"), t.id && this._setAttributeIfNotExists(e, "aria-labelledby", `${t.id}`));
  }
  _toggleDropDown(t, e) {
    const i = this._getOuterElement(t);
    if (!i.classList.contains(ru))
      return;
    const s = (r, o) => {
      const a = y.findOne(r, i);
      a && a.classList.toggle(o, e);
    };
    s(gr, ie), s(ou, ze), i.setAttribute("aria-expanded", e);
  }
  _setAttributeIfNotExists(t, e, i) {
    t.hasAttribute(e) || t.setAttribute(e, i);
  }
  _elemIsActive(t) {
    return t.classList.contains(ie);
  }
  // Try to get the inner element (usually the .nav-link)
  _getInnerElement(t) {
    return t.matches(qe) ? t : y.findOne(qe, t);
  }
  // Try to get the outer element (usually the .nav-item)
  _getOuterElement(t) {
    return t.closest(lu) || t;
  }
  // Static
  static jQueryInterface(t) {
    return this.each(function() {
      const e = dn.getOrCreateInstance(this);
      if (typeof t == "string") {
        if (e[t] === void 0 || t.startsWith("_") || t === "constructor")
          throw new TypeError(`No method named "${t}"`);
        e[t]();
      }
    });
  }
};
const br = "tab", hu = `mdb.${br}`, ye = `.${hu}`, Ii = "show.bs.tab", Mi = "shown.bs.tab", fu = "hide.bs.tab", pu = "hidden.bs.tab", _u = `show${ye}`, mu = `shown${ye}`, Eu = `hide${ye}`, gu = `hidden${ye}`, Ri = "active", xi = "fade", Pi = "show";
class $h extends du {
  constructor(t) {
    super(t), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor);
  }
  dispose() {
    u.off(this._element, Ii), u.off(this._element, Mi), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Getters
  static get NAME() {
    return br;
  }
  // Override
  show() {
    const t = this._element;
    if (this._elemIsActive(t))
      return;
    const e = this._getActiveElem();
    let i = null, s = null;
    e && (i = u.trigger(e, fu, { relatedTarget: t }), s = u.trigger(e, Eu, { relatedTarget: t }));
    const r = u.trigger(t, Ii, { relatedTarget: e }), o = u.trigger(t, _u, { relatedTarget: e });
    r.defaultPrevented || o.defaultPrevented || i && i.defaultPrevented || s && s.defaultPrevented || (this._deactivate(e, t), this._activate(t, e));
  }
  _activate(t, e) {
    if (!t)
      return;
    t.classList.add(Ri), this._activate(Wt(t));
    const i = () => {
      if (t.getAttribute("role") !== "tab") {
        t.classList.add(Pi);
        return;
      }
      t.focus(), t.removeAttribute("tabindex"), t.setAttribute("aria-selected", !0), this._toggleDropDown(t, !0), u.trigger(t, Mi, {
        relatedTarget: e
      }), u.trigger(t, mu, {
        relatedTarget: e
      });
    };
    this._queueCallback(i, t, t.classList.contains(xi));
  }
  _deactivate(t, e) {
    if (!t)
      return;
    t.classList.remove(Ri), t.blur(), this._deactivate(Wt(t));
    const i = () => {
      if (t.getAttribute("role") !== "tab") {
        t.classList.remove(Pi);
        return;
      }
      t.setAttribute("aria-selected", !1), t.setAttribute("tabindex", "-1"), this._toggleDropDown(t, !1), u.trigger(t, pu, { relatedTarget: e }), u.trigger(t, gu, { relatedTarget: e });
    };
    this._queueCallback(i, t, t.classList.contains(xi));
  }
}
const ki = "tooltip", bu = "hide.bs.tooltip", vu = "hidden.bs.tooltip", Tu = "show.bs.tooltip", Au = "shown.bs.tooltip", yu = "inserted.bs.tooltip", Nu = [
  { name: "show" },
  { name: "shown" },
  { name: "hide" },
  { name: "hidden" },
  { name: "inserted" }
];
class Ih extends Ae {
  constructor(t, e) {
    super(t, e), this._init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor);
  }
  dispose() {
    u.off(this._element, Tu), u.off(this._element, Au), u.off(this._element, bu), u.off(this._element, vu), u.off(this._element, yu), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Getters
  static get NAME() {
    return ki;
  }
  // Private
  _init() {
    this._bindMdbEvents();
  }
  _bindMdbEvents() {
    u.extend(this._element, Nu, ki);
  }
}
const Cu = "toast", wu = "bs.toast", rt = `.${wu}`, Su = `mouseover${rt}`, Ou = `mouseout${rt}`, Du = `focusin${rt}`, Lu = `focusout${rt}`, $u = `hide${rt}`, Iu = `hidden${rt}`, Mu = `show${rt}`, Ru = `shown${rt}`, xu = "fade", Hi = "hide", se = "show", re = "showing", Pu = {
  animation: "boolean",
  autohide: "boolean",
  delay: "number"
}, ku = {
  animation: !0,
  autohide: !0,
  delay: 5e3
};
let Hu = class vr extends z {
  constructor(t, e) {
    super(t, e), this._timeout = null, this._hasMouseInteraction = !1, this._hasKeyboardInteraction = !1, this._setListeners();
  }
  // Getters
  static get Default() {
    return ku;
  }
  static get DefaultType() {
    return Pu;
  }
  static get NAME() {
    return Cu;
  }
  // Public
  show() {
    if (h.trigger(this._element, Mu).defaultPrevented)
      return;
    this._clearTimeout(), this._config.animation && this._element.classList.add(xu);
    const e = () => {
      this._element.classList.remove(re), h.trigger(this._element, Ru), this._maybeScheduleHide();
    };
    this._element.classList.remove(Hi), jt(this._element), this._element.classList.add(se, re), this._queueCallback(e, this._element, this._config.animation);
  }
  hide() {
    if (!this.isShown() || h.trigger(this._element, $u).defaultPrevented)
      return;
    const e = () => {
      this._element.classList.add(Hi), this._element.classList.remove(re, se), h.trigger(this._element, Iu);
    };
    this._element.classList.add(re), this._queueCallback(e, this._element, this._config.animation);
  }
  dispose() {
    this._clearTimeout(), this.isShown() && this._element.classList.remove(se), super.dispose();
  }
  isShown() {
    return this._element.classList.contains(se);
  }
  // Private
  _maybeScheduleHide() {
    this._config.autohide && (this._hasMouseInteraction || this._hasKeyboardInteraction || (this._timeout = setTimeout(() => {
      this.hide();
    }, this._config.delay)));
  }
  _onInteraction(t, e) {
    switch (t.type) {
      case "mouseover":
      case "mouseout": {
        this._hasMouseInteraction = e;
        break;
      }
      case "focusin":
      case "focusout": {
        this._hasKeyboardInteraction = e;
        break;
      }
    }
    if (e) {
      this._clearTimeout();
      return;
    }
    const i = t.relatedTarget;
    this._element === i || this._element.contains(i) || this._maybeScheduleHide();
  }
  _setListeners() {
    h.on(this._element, Su, (t) => this._onInteraction(t, !0)), h.on(this._element, Ou, (t) => this._onInteraction(t, !1)), h.on(this._element, Du, (t) => this._onInteraction(t, !0)), h.on(this._element, Lu, (t) => this._onInteraction(t, !1));
  }
  _clearTimeout() {
    clearTimeout(this._timeout), this._timeout = null;
  }
  // Static
  static jQueryInterface(t) {
    return this.each(function() {
      const e = vr.getOrCreateInstance(this, t);
      if (typeof t == "string") {
        if (typeof e[t] > "u")
          throw new TypeError(`No method named "${t}"`);
        e[t](this);
      }
    });
  }
};
const Vi = "toast", Vu = "show.bs.toast", Bu = "shown.bs.toast", Wu = "hide.bs.toast", ju = "hidden.bs.toast", Ku = [{ name: "show" }, { name: "shown" }, { name: "hide" }, { name: "hidden" }];
class Mh extends Hu {
  constructor(t, e) {
    super(t, e), this._init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor);
  }
  dispose() {
    u.off(this._element, Vu), u.off(this._element, Bu), u.off(this._element, Wu), u.off(this._element, ju), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Getters
  static get NAME() {
    return Vi;
  }
  // Private
  _init() {
    this._bindMdbEvents();
  }
  _bindMdbEvents() {
    u.extend(this._element, Ku, Vi);
  }
}
(() => {
  var n = { 454: (i, s, r) => {
    r.d(s, { Z: () => l });
    var o = r(645), a = r.n(o)()(function(d) {
      return d[1];
    });
    a.push([i.id, "INPUT:-webkit-autofill,SELECT:-webkit-autofill,TEXTAREA:-webkit-autofill{animation-name:onautofillstart}INPUT:not(:-webkit-autofill),SELECT:not(:-webkit-autofill),TEXTAREA:not(:-webkit-autofill){animation-name:onautofillcancel}@keyframes onautofillstart{}@keyframes onautofillcancel{}", ""]);
    const l = a;
  }, 645: (i) => {
    i.exports = function(s) {
      var r = [];
      return r.toString = function() {
        return this.map(function(o) {
          var a = s(o);
          return o[2] ? "@media ".concat(o[2], " {").concat(a, "}") : a;
        }).join("");
      }, r.i = function(o, a, l) {
        typeof o == "string" && (o = [[null, o, ""]]);
        var d = {};
        if (l)
          for (var c = 0; c < this.length; c++) {
            var f = this[c][0];
            f != null && (d[f] = !0);
          }
        for (var g = 0; g < o.length; g++) {
          var b = [].concat(o[g]);
          l && d[b[0]] || (a && (b[2] ? b[2] = "".concat(a, " and ").concat(b[2]) : b[2] = a), r.push(b));
        }
      }, r;
    };
  }, 810: () => {
    (function() {
      if (typeof window < "u")
        try {
          var i = new window.CustomEvent("test", { cancelable: !0 });
          if (i.preventDefault(), i.defaultPrevented !== !0)
            throw new Error("Could not prevent default");
        } catch {
          var s = function(o, a) {
            var l, d;
            return (a = a || {}).bubbles = !!a.bubbles, a.cancelable = !!a.cancelable, (l = document.createEvent("CustomEvent")).initCustomEvent(o, a.bubbles, a.cancelable, a.detail), d = l.preventDefault, l.preventDefault = function() {
              d.call(this);
              try {
                Object.defineProperty(this, "defaultPrevented", { get: function() {
                  return !0;
                } });
              } catch {
                this.defaultPrevented = !0;
              }
            }, l;
          };
          s.prototype = window.Event.prototype, window.CustomEvent = s;
        }
    })();
  }, 379: (i, s, r) => {
    var o, a = function() {
      var E = {};
      return function(p) {
        if (E[p] === void 0) {
          var m = document.querySelector(p);
          if (window.HTMLIFrameElement && m instanceof window.HTMLIFrameElement)
            try {
              m = m.contentDocument.head;
            } catch {
              m = null;
            }
          E[p] = m;
        }
        return E[p];
      };
    }(), l = [];
    function d(E) {
      for (var p = -1, m = 0; m < l.length; m++)
        if (l[m].identifier === E) {
          p = m;
          break;
        }
      return p;
    }
    function c(E, p) {
      for (var m = {}, T = [], A = 0; A < E.length; A++) {
        var w = E[A], C = p.base ? w[0] + p.base : w[0], L = m[C] || 0, $ = "".concat(C, " ").concat(L);
        m[C] = L + 1;
        var R = d($), M = { css: w[1], media: w[2], sourceMap: w[3] };
        R !== -1 ? (l[R].references++, l[R].updater(M)) : l.push({ identifier: $, updater: I(M, p), references: 1 }), T.push($);
      }
      return T;
    }
    function f(E) {
      var p = document.createElement("style"), m = E.attributes || {};
      if (m.nonce === void 0) {
        var T = r.nc;
        T && (m.nonce = T);
      }
      if (Object.keys(m).forEach(function(w) {
        p.setAttribute(w, m[w]);
      }), typeof E.insert == "function")
        E.insert(p);
      else {
        var A = a(E.insert || "head");
        if (!A)
          throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
        A.appendChild(p);
      }
      return p;
    }
    var g, b = (g = [], function(E, p) {
      return g[E] = p, g.filter(Boolean).join(`
`);
    });
    function O(E, p, m, T) {
      var A = m ? "" : T.media ? "@media ".concat(T.media, " {").concat(T.css, "}") : T.css;
      if (E.styleSheet)
        E.styleSheet.cssText = b(p, A);
      else {
        var w = document.createTextNode(A), C = E.childNodes;
        C[p] && E.removeChild(C[p]), C.length ? E.insertBefore(w, C[p]) : E.appendChild(w);
      }
    }
    function N(E, p, m) {
      var T = m.css, A = m.media, w = m.sourceMap;
      if (A ? E.setAttribute("media", A) : E.removeAttribute("media"), w && typeof btoa < "u" && (T += `
/*# sourceMappingURL=data:application/json;base64,`.concat(btoa(unescape(encodeURIComponent(JSON.stringify(w)))), " */")), E.styleSheet)
        E.styleSheet.cssText = T;
      else {
        for (; E.firstChild; )
          E.removeChild(E.firstChild);
        E.appendChild(document.createTextNode(T));
      }
    }
    var S = null, D = 0;
    function I(E, p) {
      var m, T, A;
      if (p.singleton) {
        var w = D++;
        m = S || (S = f(p)), T = O.bind(null, m, w, !1), A = O.bind(null, m, w, !0);
      } else
        m = f(p), T = N.bind(null, m, p), A = function() {
          (function(C) {
            if (C.parentNode === null)
              return !1;
            C.parentNode.removeChild(C);
          })(m);
        };
      return T(E), function(C) {
        if (C) {
          if (C.css === E.css && C.media === E.media && C.sourceMap === E.sourceMap)
            return;
          T(E = C);
        } else
          A();
      };
    }
    i.exports = function(E, p) {
      (p = p || {}).singleton || typeof p.singleton == "boolean" || (p.singleton = (o === void 0 && (o = !!(window && document && document.all && !window.atob)), o));
      var m = c(E = E || [], p);
      return function(T) {
        if (T = T || [], Object.prototype.toString.call(T) === "[object Array]") {
          for (var A = 0; A < m.length; A++) {
            var w = d(m[A]);
            l[w].references--;
          }
          for (var C = c(T, p), L = 0; L < m.length; L++) {
            var $ = d(m[L]);
            l[$].references === 0 && (l[$].updater(), l.splice($, 1));
          }
          m = C;
        }
      };
    };
  } }, t = {};
  function e(i) {
    var s = t[i];
    if (s !== void 0)
      return s.exports;
    var r = t[i] = { id: i, exports: {} };
    return n[i](r, r.exports, e), r.exports;
  }
  e.n = (i) => {
    var s = i && i.__esModule ? () => i.default : () => i;
    return e.d(s, { a: s }), s;
  }, e.d = (i, s) => {
    for (var r in s)
      e.o(s, r) && !e.o(i, r) && Object.defineProperty(i, r, { enumerable: !0, get: s[r] });
  }, e.o = (i, s) => Object.prototype.hasOwnProperty.call(i, s), (() => {
    var i = e(379), s = e.n(i), r = e(454);
    function o(l) {
      if (!l.hasAttribute("autocompleted")) {
        l.setAttribute("autocompleted", "");
        var d = new window.CustomEvent("onautocomplete", { bubbles: !0, cancelable: !0, detail: null });
        l.dispatchEvent(d) || (l.value = "");
      }
    }
    function a(l) {
      l.hasAttribute("autocompleted") && (l.removeAttribute("autocompleted"), l.dispatchEvent(new window.CustomEvent("onautocomplete", { bubbles: !0, cancelable: !1, detail: null })));
    }
    s()(r.Z, { insert: "head", singleton: !1 }), r.Z.locals, e(810), document.addEventListener("animationstart", function(l) {
      l.animationName === "onautofillstart" ? o(l.target) : a(l.target);
    }, !0), document.addEventListener("input", function(l) {
      l.inputType !== "insertReplacementText" && "data" in l ? a(l.target) : o(l.target);
    }, !0);
  })();
})();
class Ln {
  constructor(t) {
    t = Bn(t), t && (this._element = t, et.setData(this._element, this.constructor.DATA_KEY, this));
  }
  dispose() {
    et.removeData(this._element, this.constructor.DATA_KEY), u.off(this._element, this.constructor.EVENT_KEY), Object.getOwnPropertyNames(this).forEach((t) => {
      this[t] = null;
    });
  }
  /** Static */
  static getInstance(t) {
    return et.getData(Bn(t), this.DATA_KEY);
  }
  static getOrCreateInstance(t, e = {}) {
    return this.getInstance(t) || new this(t, typeof e == "object" ? e : null);
  }
  static get NAME() {
    throw new Error('You have to implement the static method "NAME", for each component!');
  }
  static get DATA_KEY() {
    return `mdb.${this.NAME}`;
  }
  static get EVENT_KEY() {
    return `.${this.DATA_KEY}`;
  }
}
const Fu = "input", Uu = "mdb.input", oe = "active", Tr = "form-notch", Ar = "form-notch-leading", yr = "form-notch-middle", Yu = "form-notch-trailing", zu = "placeholder-active", Gu = "form-helper", qu = "form-counter", Bi = `.${Tr}`, Wi = `.${Ar}`, Xu = `.${yr}`, Qu = `.${Gu}`;
class Nr extends Ln {
  constructor(t) {
    super(t), this._label = null, this._labelWidth = 0, this._labelMarginLeft = 0, this._notchLeading = null, this._notchMiddle = null, this._notchTrailing = null, this._initiated = !1, this._helper = null, this._counter = !1, this._counterElement = null, this._maxLength = 0, this._leadingIcon = null, this._element && (this.init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor));
  }
  // Getters
  static get NAME() {
    return Fu;
  }
  get input() {
    return v.findOne("input", this._element) || v.findOne("textarea", this._element);
  }
  // Public
  init() {
    this._initiated || (this._getLabelData(), this._applyDivs(), this._applyNotch(), this._activate(), this._getHelper(), this._getCounter(), this._initiated = !0);
  }
  update() {
    this._getLabelData(), this._getNotchData(), this._applyNotch(), this._activate(), this._getHelper(), this._getCounter();
  }
  forceActive() {
    _.addClass(this.input, oe);
  }
  forceInactive() {
    _.removeClass(this.input, oe);
  }
  dispose() {
    this._removeBorder(), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Private
  /*
    _getIcons() {
      this._leadingIcon = SelectorEngine.findOne('i.leading', this._element);
  
      if (this._leadingIcon !== null) {
        this._applyLeadingIcon();
      }
    }
  
    _applyLeadingIcon() {
      this._label.innerHTML = ` ${this._label.innerHTML}`;
      this._label.insertBefore(this._leadingIcon, this._label.firstChild);
    }
    */
  _getLabelData() {
    this._label = v.findOne("label", this._element), this._label === null ? this._showPlaceholder() : (this._getLabelWidth(), this._getLabelPositionInInputGroup(), this._toggleDefaultDatePlaceholder());
  }
  _getHelper() {
    this._helper = v.findOne(Qu, this._element);
  }
  _getCounter() {
    this._counter = _.getDataAttribute(this.input, "showcounter"), this._counter && (this._maxLength = this.input.maxLength, this._showCounter());
  }
  _showCounter() {
    if (v.find(".form-counter", this._element).length > 0)
      return;
    this._counterElement = document.createElement("div"), _.addClass(this._counterElement, qu);
    const e = this.input.value.length;
    this._counterElement.innerHTML = `${e} / ${this._maxLength}`, this._helper.appendChild(this._counterElement), this._bindCounter();
  }
  _bindCounter() {
    u.on(this.input, "input", () => {
      const t = this.input.value.length;
      this._counterElement.innerHTML = `${t} / ${this._maxLength}`;
    });
  }
  _toggleDefaultDatePlaceholder(t = this.input) {
    if (!(t.getAttribute("type") === "date"))
      return;
    !(document.activeElement === t) && !t.value ? t.style.opacity = 0 : t.style.opacity = 1;
  }
  _showPlaceholder() {
    _.addClass(this.input, zu);
  }
  _getNotchData() {
    this._notchMiddle = v.findOne(Xu, this._element), this._notchLeading = v.findOne(Wi, this._element);
  }
  _getLabelWidth() {
    this._labelWidth = this._label.clientWidth * 0.8 + 8;
  }
  _getLabelPositionInInputGroup() {
    if (this._labelMarginLeft = 0, !this._element.classList.contains("input-group"))
      return;
    const t = this.input, e = v.prev(t, ".input-group-text")[0];
    e === void 0 ? this._labelMarginLeft = 0 : this._labelMarginLeft = e.offsetWidth - 1;
  }
  _applyDivs() {
    const t = v.find(Bi, this._element), e = At("div");
    _.addClass(e, Tr), this._notchLeading = At("div"), _.addClass(this._notchLeading, Ar), this._notchMiddle = At("div"), _.addClass(this._notchMiddle, yr), this._notchTrailing = At("div"), _.addClass(this._notchTrailing, Yu), !(t.length >= 1) && (e.append(this._notchLeading), e.append(this._notchMiddle), e.append(this._notchTrailing), this._element.append(e));
  }
  _applyNotch() {
    this._notchMiddle.style.width = `${this._labelWidth}px`, this._notchLeading.style.width = `${this._labelMarginLeft + 9}px`, this._label !== null && (this._label.style.marginLeft = `${this._labelMarginLeft}px`);
  }
  _removeBorder() {
    const t = v.findOne(Bi, this._element);
    t && t.remove();
  }
  _activate(t) {
    cs(() => {
      this._getElements(t);
      const e = t ? t.target : this.input;
      e.value !== "" && _.addClass(e, oe), this._toggleDefaultDatePlaceholder(e);
    });
  }
  _getElements(t) {
    if (t && (this._element = t.target.parentNode, this._label = v.findOne("label", this._element)), t && this._label) {
      const e = this._labelWidth;
      this._getLabelData(), e !== this._labelWidth && (this._notchMiddle = v.findOne(".form-notch-middle", t.target.parentNode), this._notchLeading = v.findOne(
        Wi,
        t.target.parentNode
      ), this._applyNotch());
    }
  }
  _deactivate(t) {
    const e = t ? t.target : this.input;
    e.value === "" && e.classList.remove(oe), this._toggleDefaultDatePlaceholder(e);
  }
  static activate(t) {
    return function(e) {
      t._activate(e);
    };
  }
  static deactivate(t) {
    return function(e) {
      t._deactivate(e);
    };
  }
  static jQueryInterface(t, e) {
    return this.each(function() {
      let i = et.getData(this, Uu);
      const s = typeof t == "object" && t;
      if (!(!i && /dispose/.test(t)) && (i || (i = new Nr(this, s)), typeof t == "string")) {
        if (typeof i[t] > "u")
          throw new TypeError(`No method named "${t}"`);
        i[t](e);
      }
    });
  }
}
const Zu = "collapse", Ju = "bs.collapse", Ne = `.${Ju}`, td = `show${Ne}`, ed = `shown${Ne}`, nd = `hide${Ne}`, id = `hidden${Ne}`, Xe = "show", yt = "collapse", ae = "collapsing", sd = "collapsed", rd = `:scope .${yt} .${yt}`, od = "collapse-horizontal", ad = "width", ld = "height", cd = ".collapse.show, .collapse.collapsing", ji = "[data-mdb-collapse-init]", ud = {
  parent: null,
  toggle: !0
}, dd = {
  parent: "(null|element)",
  toggle: "boolean"
};
let hd = class hn extends z {
  constructor(t, e) {
    super(t, e), this._isTransitioning = !1, this._triggerArray = [];
    const i = y.find(ji);
    for (const s of i) {
      const r = y.getSelectorFromElement(s), o = y.find(r).filter(
        (a) => a === this._element
      );
      r !== null && o.length && this._triggerArray.push(s);
    }
    this._initializeChildren(), this._config.parent || this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()), this._config.toggle && this.toggle();
  }
  // Getters
  static get Default() {
    return ud;
  }
  static get DefaultType() {
    return dd;
  }
  static get NAME() {
    return Zu;
  }
  // Public
  toggle() {
    this._isShown() ? this.hide() : this.show();
  }
  show() {
    if (this._isTransitioning || this._isShown())
      return;
    let t = [];
    if (this._config.parent && (t = this._getFirstLevelChildren(cd).filter((a) => a !== this._element).map((a) => hn.getOrCreateInstance(a, { toggle: !1 }))), t.length && t[0]._isTransitioning || h.trigger(this._element, td).defaultPrevented)
      return;
    for (const a of t)
      a.hide();
    const i = this._getDimension();
    this._element.classList.remove(yt), this._element.classList.add(ae), this._element.style[i] = 0, this._addAriaAndCollapsedClass(this._triggerArray, !0), this._isTransitioning = !0;
    const s = () => {
      this._isTransitioning = !1, this._element.classList.remove(ae), this._element.classList.add(yt, Xe), this._element.style[i] = "", h.trigger(this._element, ed);
    }, o = `scroll${i[0].toUpperCase() + i.slice(1)}`;
    this._queueCallback(s, this._element, !0), this._element.style[i] = `${this._element[o]}px`;
  }
  hide() {
    if (this._isTransitioning || !this._isShown() || h.trigger(this._element, nd).defaultPrevented)
      return;
    const e = this._getDimension();
    this._element.style[e] = `${this._element.getBoundingClientRect()[e]}px`, jt(this._element), this._element.classList.add(ae), this._element.classList.remove(yt, Xe);
    for (const s of this._triggerArray) {
      const r = y.getElementFromSelector(s);
      r && !this._isShown(r) && this._addAriaAndCollapsedClass([s], !1);
    }
    this._isTransitioning = !0;
    const i = () => {
      this._isTransitioning = !1, this._element.classList.remove(ae), this._element.classList.add(yt), h.trigger(this._element, id);
    };
    this._element.style[e] = "", this._queueCallback(i, this._element, !0);
  }
  _isShown(t = this._element) {
    return t.classList.contains(Xe);
  }
  // Private
  _configAfterMerge(t) {
    return t.toggle = !!t.toggle, t.parent = it(t.parent), t;
  }
  _getDimension() {
    return this._element.classList.contains(od) ? ad : ld;
  }
  _initializeChildren() {
    if (!this._config.parent)
      return;
    const t = this._getFirstLevelChildren(ji);
    for (const e of t) {
      const i = y.getElementFromSelector(e);
      i && this._addAriaAndCollapsedClass([e], this._isShown(i));
    }
  }
  _getFirstLevelChildren(t) {
    const e = y.find(rd, this._config.parent);
    return y.find(t, this._config.parent).filter(
      (i) => !e.includes(i)
    );
  }
  _addAriaAndCollapsedClass(t, e) {
    if (t.length)
      for (const i of t)
        i.classList.toggle(sd, !e), i.setAttribute("aria-expanded", e);
  }
  // Static
  static jQueryInterface(t) {
    const e = {};
    return typeof t == "string" && /show|hide/.test(t) && (e.toggle = !1), this.each(function() {
      const i = hn.getOrCreateInstance(this, e);
      if (typeof t == "string") {
        if (typeof i[t] > "u")
          throw new TypeError(`No method named "${t}"`);
        i[t]();
      }
    });
  }
};
const Ki = "collapse", fd = "show.bs.collapse", pd = "shown.bs.collapse", _d = "hide.bs.collapse", md = "hidden.bs.collapse", Ed = [{ name: "show" }, { name: "shown" }, { name: "hide" }, { name: "hidden" }];
class Rh extends hd {
  constructor(t, e = {}) {
    super(t, e), this._init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor);
  }
  dispose() {
    u.off(this._element, fd), u.off(this._element, pd), u.off(this._element, _d), u.off(this._element, md), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Getters
  static get NAME() {
    return Ki;
  }
  // Private
  _init() {
    this._bindMdbEvents();
  }
  _bindMdbEvents() {
    u.extend(this._element, Ed, Ki);
  }
}
const Fi = "dropdown", gd = "bs.dropdown", Ce = `.${gd}`, bd = "Escape", Ui = "Tab", vd = "ArrowUp", Yi = "ArrowDown", Td = 2, Ad = `hide${Ce}`, yd = `hidden${Ce}`, Nd = `show${Ce}`, Cd = `shown${Ce}`, Tt = "show", wd = "dropup", Sd = "dropend", Od = "dropstart", Dd = "dropup-center", Ld = "dropdown-center", Ht = "[data-mdb-dropdown-initialized]:not(.disabled):not(:disabled)", $d = `${Ht}.${Tt}`, Qe = ".dropdown-menu", Id = ".navbar", Md = ".navbar-nav", Rd = ".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)", xd = F() ? "top-end" : "top-start", Pd = F() ? "top-start" : "top-end", kd = F() ? "bottom-end" : "bottom-start", Hd = F() ? "bottom-start" : "bottom-end", Vd = F() ? "left-start" : "right-start", Bd = F() ? "right-start" : "left-start", Wd = "top", jd = "bottom", Kd = {
  autoClose: !0,
  boundary: "clippingParents",
  display: "dynamic",
  offset: [0, 2],
  popperConfig: null,
  reference: "toggle"
}, Fd = {
  autoClose: "(boolean|string)",
  boundary: "(string|element)",
  display: "string",
  offset: "(array|string|function)",
  popperConfig: "(null|object|function)",
  reference: "(string|element|object)"
};
let Ud = class de extends z {
  constructor(t, e) {
    super(t, e), this._popper = null, this._parent = this._element.parentNode, this._menu = y.next(this._element, Qe)[0] || y.prev(this._element, Qe)[0] || y.findOne(Qe, this._parent), this._inNavbar = this._detectNavbar();
  }
  // Getters
  static get Default() {
    return Kd;
  }
  static get DefaultType() {
    return Fd;
  }
  static get NAME() {
    return Fi;
  }
  // Public
  toggle() {
    return this._isShown() ? this.hide() : this.show();
  }
  show() {
    if (Nt(this._element) || this._isShown())
      return;
    const t = {
      relatedTarget: this._element
    };
    if (!h.trigger(this._element, Nd, t).defaultPrevented) {
      if (this._createPopper(), "ontouchstart" in document.documentElement && !this._parent.closest(Md))
        for (const i of [].concat(...document.body.children))
          h.on(i, "mouseover", he);
      this._element.focus(), this._element.setAttribute("aria-expanded", !0), this._menu.classList.add(Tt), this._element.classList.add(Tt), h.trigger(this._element, Cd, t);
    }
  }
  hide() {
    if (Nt(this._element) || !this._isShown())
      return;
    const t = {
      relatedTarget: this._element
    };
    this._completeHide(t);
  }
  dispose() {
    this._popper && this._popper.destroy(), super.dispose();
  }
  update() {
    this._inNavbar = this._detectNavbar(), this._popper && this._popper.update();
  }
  // Private
  _completeHide(t) {
    if (!h.trigger(this._element, Ad, t).defaultPrevented) {
      if ("ontouchstart" in document.documentElement)
        for (const i of [].concat(...document.body.children))
          h.off(i, "mouseover", he);
      this._popper && this._popper.destroy(), this._menu.classList.remove(Tt), this._element.classList.remove(Tt), this._element.setAttribute("aria-expanded", "false"), nt.removeDataAttribute(this._menu, "popper"), h.trigger(this._element, yd, t);
    }
  }
  _getConfig(t) {
    if (t = super._getConfig(t), typeof t.reference == "object" && !Q(t.reference) && typeof t.reference.getBoundingClientRect != "function")
      throw new TypeError(
        `${Fi.toUpperCase()}: Option "reference" provided type "object" without a required "getBoundingClientRect" method.`
      );
    return t;
  }
  _createPopper() {
    if (typeof ur > "u")
      throw new TypeError("Bootstrap's dropdowns require Popper (https://popper.js.org)");
    let t = this._element;
    this._config.reference === "parent" ? t = this._parent : Q(this._config.reference) ? t = it(this._config.reference) : typeof this._config.reference == "object" && (t = this._config.reference);
    const e = this._getPopperConfig();
    this._popper = Dn(t, this._menu, e);
  }
  _isShown() {
    return this._menu.classList.contains(Tt);
  }
  _getPlacement() {
    const t = this._parent;
    if (t.classList.contains(Sd))
      return Vd;
    if (t.classList.contains(Od))
      return Bd;
    if (t.classList.contains(Dd))
      return Wd;
    if (t.classList.contains(Ld))
      return jd;
    const e = getComputedStyle(this._menu).getPropertyValue("--mdb-position").trim() === "end";
    return t.classList.contains(wd) ? e ? Pd : xd : e ? Hd : kd;
  }
  _detectNavbar() {
    return this._element.closest(Id) !== null;
  }
  _getOffset() {
    const { offset: t } = this._config;
    return typeof t == "string" ? t.split(",").map((e) => Number.parseInt(e, 10)) : typeof t == "function" ? (e) => t(e, this._element) : t;
  }
  _getPopperConfig() {
    const t = {
      placement: this._getPlacement(),
      modifiers: [
        {
          name: "preventOverflow",
          options: {
            boundary: this._config.boundary
          }
        },
        {
          name: "offset",
          options: {
            offset: this._getOffset()
          }
        }
      ]
    };
    return (this._inNavbar || this._config.display === "static") && (nt.setDataAttribute(this._menu, "popper", "static"), t.modifiers = [
      {
        name: "applyStyles",
        enabled: !1
      }
    ]), {
      ...t,
      ...k(this._config.popperConfig, [t])
    };
  }
  _selectMenuItem({ key: t, target: e }) {
    const i = y.find(Rd, this._menu).filter(
      (s) => Ee(s)
    );
    i.length && _n(i, e, t === Yi, !i.includes(e)).focus();
  }
  // Static
  static jQueryInterface(t) {
    return this.each(function() {
      const e = de.getOrCreateInstance(this, t);
      if (typeof t == "string") {
        if (typeof e[t] > "u")
          throw new TypeError(`No method named "${t}"`);
        e[t]();
      }
    });
  }
  static clearMenus(t) {
    if (t.button === Td || t.type === "keyup" && t.key !== Ui)
      return;
    const e = y.find($d);
    for (const i of e) {
      const s = de.getInstance(i);
      if (!s || s._config.autoClose === !1)
        continue;
      const r = t.composedPath(), o = r.includes(s._menu);
      if (r.includes(s._element) || s._config.autoClose === "inside" && !o || s._config.autoClose === "outside" && o || s._menu.contains(t.target) && (t.type === "keyup" && t.key === Ui || /input|select|option|textarea|form/i.test(t.target.tagName)))
        continue;
      const a = { relatedTarget: s._element };
      t.type === "click" && (a.clickEvent = t), s._completeHide(a);
    }
  }
  static dataApiKeydownHandler(t) {
    const e = /input|textarea/i.test(t.target.tagName), i = t.key === bd, s = [vd, Yi].includes(t.key);
    if (!s && !i || e && !i)
      return;
    t.preventDefault();
    const r = this.matches(Ht) ? this : y.prev(this, Ht)[0] || y.next(this, Ht)[0] || y.findOne(Ht, t.delegateTarget.parentNode), o = de.getOrCreateInstance(r);
    if (s) {
      t.stopPropagation(), o.show(), o._selectMenuItem(t);
      return;
    }
    o._isShown() && (t.stopPropagation(), o.hide(), r.focus());
  }
};
const fn = "dropdown", Yd = `mdb.${fn}`, we = `.${Yd}`, zd = {
  offset: [0, 2],
  flip: !0,
  boundary: "clippingParents",
  reference: "toggle",
  display: "dynamic",
  popperConfig: null,
  dropdownAnimation: "on"
}, Gd = {
  offset: "(array|string|function)",
  flip: "boolean",
  boundary: "(string|element)",
  reference: "(string|element|object)",
  display: "string",
  popperConfig: "(null|object|function)",
  dropdownAnimation: "string"
}, zi = "hide.bs.dropdown", Gi = "hidden.bs.dropdown", qi = "show.bs.dropdown", Xi = "shown.bs.dropdown", qd = `hide${we}`, Xd = `hidden${we}`, Qd = `show${we}`, Zd = `shown${we}`, Ze = "animation", Je = "fade-in", tn = "fade-out";
class xh extends Ud {
  constructor(t, e) {
    super(t, e), this._config = this._getConfig(e), this._menuStyle = "", this._popperPlacement = "", this._mdbPopperConfig = "";
    const i = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    this._config.dropdownAnimation === "on" && !i && this._init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor);
  }
  dispose() {
    u.off(this._element, qi), u.off(this._parent, Xi), u.off(this._parent, zi), u.off(this._parent, Gi), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Getters
  static get NAME() {
    return fn;
  }
  // Private
  _init() {
    this._bindShowEvent(), this._bindShownEvent(), this._bindHideEvent(), this._bindHiddenEvent();
  }
  _getConfig(t) {
    const e = {
      ...zd,
      ..._.getDataAttributes(this._element),
      ...t
    };
    return rs(fn, e, Gd), e;
  }
  _getOffset() {
    const { offset: t } = this._config;
    return typeof t == "string" ? t.split(",").map((e) => Number.parseInt(e, 10)) : typeof t == "function" ? (e) => t(e, this._element) : t;
  }
  _getPopperConfig() {
    const t = {
      placement: this._getPlacement(),
      modifiers: [
        {
          name: "preventOverflow",
          options: {
            altBoundary: this._config.flip,
            boundary: this._config.boundary
          }
        },
        {
          name: "offset",
          options: {
            offset: this._getOffset()
          }
        }
      ]
    };
    return this._config.display === "static" && (_.setDataAttribute(this._menu, "popper", "static"), t.modifiers = [
      {
        name: "applyStyles",
        enabled: !1
      }
    ]), {
      ...t,
      /* eslint no-extra-parens: "off" */
      ...typeof this._config.popperConfig == "function" ? this._config.popperConfig(t) : this._config.popperConfig
    };
  }
  _bindShowEvent() {
    u.on(this._element, qi, (t) => {
      if (u.trigger(this._element, Qd, {
        relatedTarget: t.relatedTarget
      }).defaultPrevented) {
        t.preventDefault();
        return;
      }
      this._dropdownAnimationStart("show");
    });
  }
  _bindShownEvent() {
    u.on(this._parent, Xi, (t) => {
      if (u.trigger(this._parent, Zd, {
        relatedTarget: t.relatedTarget
      }).defaultPrevented) {
        t.preventDefault();
        return;
      }
    });
  }
  _bindHideEvent() {
    u.on(this._parent, zi, (t) => {
      if (u.trigger(this._parent, qd, {
        relatedTarget: t.relatedTarget
      }).defaultPrevented) {
        t.preventDefault();
        return;
      }
      this._menuStyle = this._menu.style.cssText, this._popperPlacement = this._menu.getAttribute("data-popper-placement"), this._mdbPopperConfig = this._menu.getAttribute("data-mdb-popper");
    });
  }
  _bindHiddenEvent() {
    u.on(this._parent, Gi, (t) => {
      if (u.trigger(this._parent, Xd, {
        relatedTarget: t.relatedTarget
      }).defaultPrevented) {
        t.preventDefault();
        return;
      }
      this._config.display !== "static" && this._menuStyle !== "" && (this._menu.style.cssText = this._menuStyle), this._menu.setAttribute("data-popper-placement", this._popperPlacement), this._menu.setAttribute("data-mdb-popper", this._mdbPopperConfig), this._dropdownAnimationStart("hide");
    });
  }
  _dropdownAnimationStart(t) {
    switch (t) {
      case "show":
        this._menu.classList.add(Ze, Je), this._menu.classList.remove(tn);
        break;
      default:
        this._menu.classList.add(Ze, tn), this._menu.classList.remove(Je);
        break;
    }
    this._bindAnimationEnd();
  }
  _bindAnimationEnd() {
    u.one(this._menu, "animationend", () => {
      this._menu.classList.remove(Ze, tn, Je);
    });
  }
}
const pn = "ripple", Jd = "mdb.ripple", X = "ripple-surface", Qi = "ripple-wave", Zi = "input-wrapper", th = ".btn", eh = [th, `[data-mdb-${pn}-init]`], Ji = "ripple-surface-unbound", nh = "rgba({{color}}, 0.2) 0, rgba({{color}}, 0.3) 40%, rgba({{color}}, 0.4) 50%, rgba({{color}}, 0.5) 60%, rgba({{color}}, 0) 70%", le = [0, 0, 0], ih = [
  "primary",
  "secondary",
  "success",
  "danger",
  "warning",
  "info",
  "light",
  "dark"
], ts = 0.5, sh = {
  rippleCentered: !1,
  rippleColor: "",
  rippleDuration: "500ms",
  rippleRadius: 0,
  rippleUnbound: !1
}, rh = {
  rippleCentered: "boolean",
  rippleColor: "string",
  rippleDuration: "string",
  rippleRadius: "number",
  rippleUnbound: "boolean"
};
class Cr extends Ln {
  constructor(t, e) {
    super(t), this._options = this._getConfig(e), this._element && (_.addClass(this._element, X), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor)), this._clickHandler = this._createRipple.bind(this), this._rippleTimer = null, this._isMinWidthSet = !1, this._rippleInSpan = !1, this.init();
  }
  // Getters
  static get NAME() {
    return pn;
  }
  // Public
  init() {
    this._addClickEvent(this._element);
  }
  dispose() {
    u.off(this._element, "mousedown", this._clickHandler), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Private
  _autoInit(t) {
    eh.forEach((i) => {
      v.closest(t.target, i) && (this._element = v.closest(t.target, i));
    });
    const e = _.getDataAttributes(this._element);
    if (!(this._element.classList.contains("btn") && e.rippleInit === !1)) {
      if (this._options = this._getConfig(), this._element.tagName.toLowerCase() === "input") {
        const i = this._element.parentNode;
        if (this._rippleInSpan = !0, i.tagName.toLowerCase() === "span" && i.classList.contains(X))
          this._element = i;
        else {
          const s = getComputedStyle(this._element).boxShadow, r = this._element, o = document.createElement("span");
          r.classList.contains("btn-block") && (o.style.display = "block"), u.one(o, "mouseup", (a) => {
            a.button === 0 && r.click();
          }), o.classList.add(X, Zi), _.addStyle(o, {
            border: 0,
            "box-shadow": s
          }), i.replaceChild(o, this._element), o.appendChild(this._element), this._element = o;
        }
        this._element.focus();
      }
      this._element.style.minWidth || (_.style(this._element, { "min-width": `${getComputedStyle(this._element).width}` }), this._isMinWidthSet = !0), _.addClass(this._element, X), this._createRipple(t);
    }
  }
  _addClickEvent(t) {
    u.on(t, "mousedown", this._clickHandler);
  }
  _getEventLayer(t) {
    const e = Math.round(t.clientX - t.target.getBoundingClientRect().x), i = Math.round(t.clientY - t.target.getBoundingClientRect().y);
    return { layerX: e, layerY: i };
  }
  _createRipple(t) {
    if (this._element === null)
      return;
    _.hasClass(this._element, X) || _.addClass(this._element, X);
    const { layerX: e, layerY: i } = this._getEventLayer(t), s = e, r = i, o = this._element.offsetHeight, a = this._element.offsetWidth, l = this._durationToMsNumber(this._options.rippleDuration), d = {
      offsetX: this._options.rippleCentered ? o / 2 : s,
      offsetY: this._options.rippleCentered ? a / 2 : r,
      height: o,
      width: a
    }, c = this._getDiameter(d), f = this._options.rippleRadius || c / 2, g = {
      delay: l * ts,
      duration: l - l * ts
    }, b = {
      left: this._options.rippleCentered ? `${a / 2 - f}px` : `${s - f}px`,
      top: this._options.rippleCentered ? `${o / 2 - f}px` : `${r - f}px`,
      height: `${this._options.rippleRadius * 2 || c}px`,
      width: `${this._options.rippleRadius * 2 || c}px`,
      transitionDelay: `0s, ${g.delay}ms`,
      transitionDuration: `${l}ms, ${g.duration}ms`
    }, O = At("div");
    this._createHTMLRipple({ wrapper: this._element, ripple: O, styles: b }), this._removeHTMLRipple({ ripple: O, duration: l });
  }
  _createHTMLRipple({ wrapper: t, ripple: e, styles: i }) {
    Object.keys(i).forEach((s) => e.style[s] = i[s]), e.classList.add(Qi), this._options.rippleColor !== "" && (this._removeOldColorClasses(t), this._addColor(e, t)), this._toggleUnbound(t), this._appendRipple(e, t);
  }
  _removeHTMLRipple({ ripple: t, duration: e }) {
    this._rippleTimer && (clearTimeout(this._rippleTimer), this._rippleTimer = null), this._rippleTimer = setTimeout(() => {
      t && (t.remove(), this._element && (v.find(`.${Qi}`, this._element).forEach((i) => {
        i.remove();
      }), this._isMinWidthSet && (_.style(this._element, { "min-width": "" }), this._isMinWidthSet = !1), this._rippleInSpan && this._element.classList.contains(Zi) ? this._removeWrapperSpan() : _.removeClass(this._element, X)));
    }, e);
  }
  _removeWrapperSpan() {
    const t = this._element.firstChild;
    this._element.replaceWith(t), this._element = t, this._element.focus(), this._rippleInSpan = !1;
  }
  _durationToMsNumber(t) {
    return Number(t.replace("ms", "").replace("s", "000"));
  }
  _getConfig(t = {}) {
    const e = _.getDataAttributes(this._element);
    return t = {
      ...sh,
      ...e,
      ...t
    }, rs(pn, t, rh), t;
  }
  _getDiameter({ offsetX: t, offsetY: e, height: i, width: s }) {
    const r = e <= i / 2, o = t <= s / 2, a = (g, b) => Math.sqrt(g ** 2 + b ** 2), l = e === i / 2 && t === s / 2, d = {
      first: r === !0 && o === !1,
      second: r === !0 && o === !0,
      third: r === !1 && o === !0,
      fourth: r === !1 && o === !1
    }, c = {
      topLeft: a(t, e),
      topRight: a(s - t, e),
      bottomLeft: a(t, i - e),
      bottomRight: a(s - t, i - e)
    };
    let f = 0;
    return l || d.fourth ? f = c.topLeft : d.third ? f = c.topRight : d.second ? f = c.bottomRight : d.first && (f = c.bottomLeft), f * 2;
  }
  _appendRipple(t, e) {
    e.appendChild(t), setTimeout(() => {
      _.addClass(t, "active");
    }, 50);
  }
  _toggleUnbound(t) {
    this._options.rippleUnbound === !0 ? _.addClass(t, Ji) : t.classList.remove(Ji);
  }
  _addColor(t, e) {
    if (ih.find(
      (s) => s === this._options.rippleColor.toLowerCase()
    ))
      _.addClass(
        e,
        `${X}-${this._options.rippleColor.toLowerCase()}`
      );
    else {
      const s = this._colorToRGB(this._options.rippleColor).join(","), r = nh.split("{{color}}").join(`${s}`);
      t.style.backgroundImage = `radial-gradient(circle, ${r})`;
    }
  }
  _removeOldColorClasses(t) {
    const e = new RegExp(`${X}-[a-z]+`, "gi");
    (t.classList.value.match(e) || []).forEach((s) => {
      t.classList.remove(s);
    });
  }
  _colorToRGB(t) {
    function e(r) {
      return r.length < 7 && (r = `#${r[1]}${r[1]}${r[2]}${r[2]}${r[3]}${r[3]}`), [
        parseInt(r.substr(1, 2), 16),
        parseInt(r.substr(3, 2), 16),
        parseInt(r.substr(5, 2), 16)
      ];
    }
    function i(r) {
      const o = document.body.appendChild(document.createElement("fictum")), a = "rgb(1, 2, 3)";
      return o.style.color = a, o.style.color !== a || (o.style.color = r, o.style.color === a || o.style.color === "") ? le : (r = getComputedStyle(o).color, document.body.removeChild(o), r);
    }
    function s(r) {
      return r = r.match(/[.\d]+/g).map((o) => +Number(o)), r.length = 3, r;
    }
    return t.toLowerCase() === "transparent" ? le : t[0] === "#" ? e(t) : (t.indexOf("rgb") === -1 && (t = i(t)), t.indexOf("rgb") === 0 ? s(t) : le);
  }
  // Static
  static autoInitial(t) {
    return function(e) {
      t._autoInit(e);
    };
  }
  static jQueryInterface(t) {
    return this.each(function() {
      return et.getData(this, Jd) ? null : new Cr(this, t);
    });
  }
}
const oh = "range", ah = "mdb.range", wr = "thumb", es = "thumb-active", lh = "thumb-value", ch = `.${lh}`, uh = `.${wr}`;
class Sr extends Ln {
  constructor(t) {
    super(t), this._initiated = !1, this._thumb = null, this._element && (this.init(), _.setDataAttribute(this._element, `${this.constructor.NAME}-initialized`, !0), H(this.constructor));
  }
  // Getters
  static get NAME() {
    return oh;
  }
  get rangeInput() {
    return v.findOne("input[type=range]", this._element);
  }
  // Public
  init() {
    this._initiated || (this._addThumb(), this._thumbUpdate(), this._handleEvents(), this._initiated = !0);
  }
  dispose() {
    this._disposeEvents(), _.removeDataAttribute(this._element, `${this.constructor.NAME}-initialized`), super.dispose();
  }
  // Private
  _addThumb() {
    const t = At("span");
    _.addClass(t, wr), t.innerHTML = '<span class="thumb-value"></span>', this._element.append(t), this._thumb = v.findOne(uh, this._element);
  }
  _handleEvents() {
    u.on(this.rangeInput, "mousedown", () => this._showThumb()), u.on(this.rangeInput, "mouseup", () => this._hideThumb()), u.on(this.rangeInput, "touchstart", () => this._showThumb()), u.on(this.rangeInput, "touchend", () => this._hideThumb()), u.on(this.rangeInput, "input", () => this._thumbUpdate());
  }
  _disposeEvents() {
    u.off(this.rangeInput, "mousedown"), u.off(this.rangeInput, "mouseup"), u.off(this.rangeInput, "touchstart"), u.off(this.rangeInput, "touchend"), u.off(this.rangeInput, "input");
  }
  _showThumb() {
    _.addClass(this._thumb, es);
  }
  _hideThumb() {
    _.removeClass(this._thumb, es);
  }
  _thumbUpdate() {
    const t = this.rangeInput, e = t.value, i = t.min ? t.min : 0, s = t.max ? t.max : 100, r = v.findOne(ch, this._thumb);
    r.textContent = e;
    const o = Number((e - i) * 100 / (s - i));
    _.style(this._thumb, { left: `calc(${o}% + (${8 - o * 0.15}px))` });
  }
  // Static
  static jQueryInterface(t, e) {
    return this.each(function() {
      let i = et.getData(this, ah);
      const s = typeof t == "object" && t;
      if (!(!i && /dispose/.test(t)) && (i || (i = new Sr(this, s)), typeof t == "string")) {
        if (typeof i[t] > "u")
          throw new TypeError(`No method named "${t}"`);
        i[t](e);
      }
    });
  }
}
const dh = (n, t) => {
  const e = n;
  ge(e, "close"), v.find(t).forEach((i) => e.getOrCreateInstance(i));
}, hh = (n, t) => {
  const e = n, i = `click.bs.${n.name}.data-api`;
  u.on(document, i, t, (s) => {
    s.preventDefault();
    const r = s.target.closest(t);
    e.getOrCreateInstance(r).toggle();
  }), v.find(t).forEach((s) => e.getOrCreateInstance(s));
}, fh = (n, t) => {
  const e = `click.bs.${n.name}.data-api`, i = "[data-mdb-slide], [data-mdb-slide-to]", s = "carousel", r = n, o = `load.bs.${n.name}.data-api`, a = t;
  u.on(document, e, i, function(l) {
    const d = Wt(this);
    if (!d || !d.classList.contains(s))
      return;
    l.preventDefault();
    const c = r.getOrCreateInstance(d), f = this.getAttribute("data-mdb-slide-to");
    if (f) {
      c.to(f), c._maybeEnableCycle();
      return;
    }
    if (_.getDataAttribute(this, "slide") === "next") {
      c.next(), c._maybeEnableCycle();
      return;
    }
    c.prev(), c._maybeEnableCycle();
  }), u.on(window, o, () => {
    v.find(a).forEach((d) => {
      r.getOrCreateInstance(d);
    });
  });
}, ph = (n, t) => {
  const e = `click.bs.${n.name}.data-api`, i = t, s = n;
  u.on(document, e, i, function(r) {
    (r.target.tagName === "A" || r.delegateTarget && r.delegateTarget.tagName === "A") && r.preventDefault();
    const o = en(this);
    v.find(o).forEach((l) => {
      s.getOrCreateInstance(l, { toggle: !1 }).toggle();
    });
  }), v.find(i).forEach((r) => {
    const o = en(r);
    v.find(o).forEach((l) => {
      s.getOrCreateInstance(l, { toggle: !1 });
    });
  });
}, _h = (n, t) => {
  const e = `click.bs.${n.name}.data-api`, i = `keydown.bs.${n.name}.data-api`, s = `keyup.bs.${n.name}.data-api`, r = ".dropdown-menu", o = `[data-mdb-${n.NAME}-initialized]`, a = n;
  u.on(
    document,
    i,
    o,
    a.dataApiKeydownHandler
  ), u.on(document, i, r, a.dataApiKeydownHandler), u.on(document, e, a.clearMenus), u.on(document, s, a.clearMenus), u.on(document, e, o, function(l) {
    l.preventDefault(), a.getOrCreateInstance(this).toggle();
  }), v.find(t).forEach((l) => {
    a.getOrCreateInstance(l);
  });
}, mh = (n, t) => {
  const e = t, i = `${e} input`, s = `${e} textarea`, r = n;
  u.on(document, "focus", i, r.activate(new r())), u.on(document, "input", i, r.activate(new r())), u.on(document, "blur", i, r.deactivate(new r())), u.on(document, "focus", s, r.activate(new r())), u.on(document, "input", s, r.activate(new r())), u.on(document, "blur", s, r.deactivate(new r())), u.on(window, "shown.bs.modal", (o) => {
    v.find(i, o.target).forEach((a) => {
      const l = r.getInstance(a.parentNode);
      l && l.update();
    }), v.find(s, o.target).forEach((a) => {
      const l = r.getInstance(a.parentNode);
      l && l.update();
    });
  }), u.on(window, "shown.bs.dropdown", (o) => {
    const a = o.target.parentNode.querySelector(".dropdown-menu");
    a && (v.find(i, a).forEach((l) => {
      const d = r.getInstance(l.parentNode);
      d && d.update();
    }), v.find(s, a).forEach((l) => {
      const d = r.getInstance(l.parentNode);
      d && d.update();
    }));
  }), u.on(window, "shown.bs.tab", (o) => {
    let a;
    o.target.href ? a = o.target.href.split("#")[1] : a = _.getDataAttribute(o.target, "target").split("#")[1];
    const l = v.findOne(`#${a}`);
    v.find(i, l).forEach((d) => {
      const c = r.getInstance(d.parentNode);
      c && c.update();
    }), v.find(s, l).forEach((d) => {
      const c = r.getInstance(d.parentNode);
      c && c.update();
    });
  }), v.find(e).map((o) => new r(o)), u.on(window, "reset", (o) => {
    v.find(i, o.target).forEach((a) => {
      const l = r.getInstance(a.parentNode);
      l && l.forceInactive();
    }), v.find(s, o.target).forEach((a) => {
      const l = r.getInstance(a.parentNode);
      l && l.forceInactive();
    });
  }), u.on(window, "onautocomplete", (o) => {
    const a = r.getInstance(o.target.parentNode);
    !a || !o.cancelable || a.forceActive();
  });
}, Eh = (n, t) => {
  const e = `click.bs.${n.name}.data-api`, i = ".modal.show", s = n, r = `show.bs.${n.name}`, o = `hidden.bs.${n.name}`;
  u.on(document, e, t, function(a) {
    const l = Wt(this);
    ["A", "AREA"].includes(this.tagName) && a.preventDefault(), u.one(l, r, (f) => {
      f.defaultPrevented || u.one(l, o, () => {
        os(this) && this.focus();
      });
    }), v.find(i).forEach((f) => {
      f.classList.contains("modal-non-invasive-show") || s.getInstance(f).hide();
    }), s.getOrCreateInstance(l).toggle(this);
  }), ge(s), v.find(t).forEach((a) => {
    const l = en(a), d = v.findOne(l);
    s.getOrCreateInstance(d);
  });
}, gh = (n, t) => {
  const e = `click.bs.${n.name}.data-api`, i = ".offcanvas.show", s = n, r = `hidden.bs.${n.name}`, o = `load.bs.${n.name}.data-api`, a = `resize.bs.${n.name}`;
  u.on(document, e, t, function(l) {
    const d = Wt(this);
    if (["A", "AREA"].includes(this.tagName) && l.preventDefault(), as(this))
      return;
    u.one(d, r, () => {
      os(this) && this.focus();
    });
    const c = v.findOne(i);
    c && c !== d && s.getInstance(c).hide(), s.getOrCreateInstance(d).toggle(this);
  }), u.on(window, o, () => {
    v.find(i).forEach((l) => {
      s.getOrCreateInstance(l).show();
    });
  }), u.on(window, a, () => {
    v.find("[aria-modal][class*=show][class*=offcanvas-]").forEach((l) => {
      getComputedStyle(l).position !== "fixed" && s.getOrCreateInstance(l).hide();
    });
  }), ge(s);
}, bh = (n, t) => {
  const e = `load.bs.${n.name}.data-api`, i = n;
  u.on(window, e, () => {
    v.find(t).forEach((s) => {
      i.getOrCreateInstance(s);
    });
  });
}, vh = (n, t) => {
  const e = `load.bs.${n.name}.data-api`, i = `click.bs.${n.name}.data-api`, s = "active", r = `.${s}[data-mdb-tab-init], .${s}[data-mdb-pill-init], .${s}[data-mdb-toggle="list"]`, o = n;
  u.on(document, i, t, function(a) {
    ["A", "AREA"].includes(this.tagName) && a.preventDefault(), !as(this) && o.getOrCreateInstance(this).show();
  }), u.on(window, e, () => {
    v.find(r).forEach((a) => {
      o.getOrCreateInstance(a);
    });
  });
}, Th = (n, t) => {
  const e = n;
  ge(e), v.find(t).forEach((i) => e.getOrCreateInstance(i));
}, ns = (n, t) => {
  const e = n;
  u.one(document, "mousedown", t, e.autoInitial(new e()));
}, Ah = {
  // Bootstrap Components
  alert: {
    name: "Alert",
    selector: "[data-mdb-alert-init]",
    isToggler: !0,
    callback: dh
  },
  button: {
    name: "Button",
    selector: "[data-mdb-button-init]",
    isToggler: !0,
    callback: hh
  },
  carousel: {
    name: "Carousel",
    selector: "[data-mdb-carousel-init]",
    isToggler: !0,
    callback: fh
  },
  collapse: {
    name: "Collapse",
    selector: "[data-mdb-collapse-init]",
    isToggler: !0,
    callback: ph
  },
  dropdown: {
    name: "Dropdown",
    selector: "[data-mdb-dropdown-init]",
    isToggler: !0,
    callback: _h
  },
  modal: {
    name: "Modal",
    selector: "[data-mdb-modal-init]",
    isToggler: !0,
    callback: Eh
  },
  offcanvas: {
    name: "Offcanvas",
    selector: "[data-mdb-offcanvas-init]",
    isToggler: !0,
    callback: gh
  },
  scrollspy: {
    name: "ScrollSpy",
    selector: "[data-mdb-scrollspy-init]",
    isToggler: !0,
    callback: bh
  },
  tab: {
    name: "Tab",
    selector: "[data-mdb-tab-init], [data-mdb-pill-init], [data-mdb-list-init]",
    isToggler: !0,
    callback: vh
  },
  toast: {
    name: "Toast",
    selector: "[data-mdb-toast-init]",
    isToggler: !0,
    callback: Th
  },
  tooltip: {
    name: "Tooltip",
    selector: "[data-mdb-tooltip-init]",
    isToggler: !1
  },
  input: {
    name: "Input",
    selector: "[data-mdb-input-init]",
    isToggler: !0,
    callback: mh
  },
  range: {
    name: "Range",
    selector: "[data-mdb-range-init]",
    isToggler: !1
  },
  ripple: {
    name: "Ripple",
    selector: "[data-mdb-ripple-init]",
    isToggler: !0,
    callback: ns
  },
  popover: {
    name: "Popover",
    selector: "[data-mdb-popover-init]",
    isToggler: !1,
    callback: ns
  }
}, yh = new co(Ah), Ph = yh.initMDB;
export {
  wh as Alert,
  Ds as Button,
  Sh as Carousel,
  Rh as Collapse,
  xh as Dropdown,
  Nr as Input,
  Oh as Modal,
  Ms as Offcanvas,
  Dh as Popover,
  Sr as Range,
  Cr as Ripple,
  Lh as ScrollSpy,
  $h as Tab,
  Mh as Toast,
  Ih as Tooltip,
  Ph as initMDB
};
//# sourceMappingURL=mdb.es.min.js.b845c5736274.map
